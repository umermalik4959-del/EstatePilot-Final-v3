import 'package:flutter/services.dart';

class NativeBridge {
  static const MethodChannel _channel = MethodChannel('estatepilot/native');

  static Future<String> getDataPath() async =>
      await _channel.invokeMethod<String>('getDataPath') ?? '';

  static Future<String> loadSnapshot() async =>
      await _channel.invokeMethod<String>('loadSnapshot') ?? '{}';

  static Future<void> saveSnapshot(String snapshot) async {
    await _channel.invokeMethod<bool>('saveSnapshot', {'snapshot': snapshot});
  }

  /// SAF: user chooses destination. No storage permission required.
  static Future<bool> exportBackup(String json) async =>
      await _channel.invokeMethod<String>('exportBackup', {'json': json}) == 'saved';

  /// SAF: user chooses backup file. Null means the picker was cancelled.
  static Future<String?> importBackup() => _channel.invokeMethod<String>('importBackup');

  static Future<void> openDialer(String phone) async {
    await _channel.invokeMethod<void>('openDialer', {'phone': phone});
  }

  static Future<void> openWhatsApp(String phone, {String? message}) async {
    await _channel.invokeMethod<void>('openWhatsApp',
      {'phone': phone, 'message': message ?? ''});
  }

  static Future<void> shareText(String text) async {
    await _channel.invokeMethod<void>('shareText', {'text': text});
  }
}
