import 'package:flutter/material.dart';

/// EstatePilot brand system. The original luxury black / warm brown / gold
/// identity is intentionally centralized here so screens cannot drift into
/// unrelated colors or generic admin-template styling.
class EstatePilotTheme {
  static const Color primaryBackground = Color(0xFF101010);
  static const Color secondaryBackground = Color(0xFF181614);
  static const Color surface = Color(0xFF211D19);
  static const Color warmBrown = Color(0xFF493426);
  static const Color deepBrown = Color(0xFF30231C);
  static const Color gold = Color(0xFFC6A06A);
  static const Color lightGold = Color(0xFFD9B77E);
  static const Color textPrimary = Color(0xFFF5F0E8);
  static const Color textSecondary = Color(0xFFB8ADA1);
  static const Color divider = Color(0xFF39312A);
  static const Color success = Color(0xFF6F8C68);
  static const Color warning = Color(0xFFB68A4A);
  static const Color error = Color(0xFFA95A55);
  static const Color lightCanvas = Color(0xFFF4EFE7);
  static const Color lightSurface = Color(0xFFFFFBF5);
  static const Color darkText = Color(0xFF241D18);
  static const Color cream = lightCanvas;
  static const Color charcoal = surface;
  static const Color line = divider;

  static ThemeData get dark {
    const scheme = ColorScheme.dark(
      primary: gold,
      onPrimary: Color(0xFF21170F),
      secondary: lightGold,
      onSecondary: Color(0xFF21170F),
      surface: surface,
      onSurface: textPrimary,
      error: error,
      onError: Colors.white,
      outline: divider,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: primaryBackground,
      canvasColor: primaryBackground,
      splashColor: gold.withValues(alpha: .08),
      highlightColor: gold.withValues(alpha: .05),
      dividerColor: divider,
      fontFamily: 'Roboto',
      textTheme: const TextTheme(
        headlineLarge: TextStyle(color: textPrimary, fontWeight: FontWeight.w800),
        headlineMedium: TextStyle(color: textPrimary, fontWeight: FontWeight.w800),
        headlineSmall: TextStyle(color: textPrimary, fontWeight: FontWeight.w800),
        titleLarge: TextStyle(color: textPrimary, fontWeight: FontWeight.w800),
        titleMedium: TextStyle(color: textPrimary, fontWeight: FontWeight.w700),
        titleSmall: TextStyle(color: textPrimary, fontWeight: FontWeight.w700),
        bodyLarge: TextStyle(color: textPrimary),
        bodyMedium: TextStyle(color: textPrimary),
        bodySmall: TextStyle(color: textSecondary),
        labelLarge: TextStyle(fontWeight: FontWeight.w700),
      ),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: primaryBackground,
        foregroundColor: textPrimary,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
      ),
      cardTheme: const CardThemeData(
        elevation: 0,
        color: surface,
        margin: EdgeInsets.zero,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(18)),
          side: BorderSide(color: divider),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: secondaryBackground,
        labelStyle: const TextStyle(color: textSecondary),
        hintStyle: TextStyle(color: textSecondary.withValues(alpha: .70)),
        prefixIconColor: textSecondary,
        suffixIconColor: textSecondary,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: divider),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: divider),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: gold, width: 1.4),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: error),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: gold,
          foregroundColor: const Color(0xFF21170F),
          disabledBackgroundColor: divider,
          disabledForegroundColor: textSecondary,
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: textPrimary,
          side: const BorderSide(color: divider),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(foregroundColor: lightGold),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: gold,
        foregroundColor: Color(0xFF21170F),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 70,
        backgroundColor: const Color(0xFF151311),
        surfaceTintColor: Colors.transparent,
        indicatorColor: gold.withValues(alpha: .16),
        labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
          fontSize: 11,
          fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600,
          color: states.contains(WidgetState.selected) ? lightGold : textSecondary,
        )),
        iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
          color: states.contains(WidgetState.selected) ? gold : textSecondary,
        )),
      ),
      chipTheme: ChipThemeData(
        side: const BorderSide(color: divider),
        backgroundColor: secondaryBackground,
        selectedColor: gold.withValues(alpha: .14),
        labelStyle: const TextStyle(color: textPrimary, fontWeight: FontWeight.w600),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
      dialogTheme: const DialogThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(20))),
      ),
      bottomSheetTheme: const BottomSheetThemeData(
        backgroundColor: surface,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
      ),
      snackBarTheme: const SnackBarThemeData(
        backgroundColor: deepBrown,
        contentTextStyle: TextStyle(color: textPrimary),
        behavior: SnackBarBehavior.floating,
      ),
      listTileTheme: const ListTileThemeData(
        iconColor: textSecondary,
        textColor: textPrimary,
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) =>
          states.contains(WidgetState.selected) ? gold : textSecondary),
        trackColor: WidgetStateProperty.resolveWith((states) =>
          states.contains(WidgetState.selected) ? gold.withValues(alpha: .34) : divider),
      ),
      checkboxTheme: CheckboxThemeData(
        fillColor: WidgetStateProperty.resolveWith((states) =>
          states.contains(WidgetState.selected) ? gold : Colors.transparent),
        checkColor: const WidgetStatePropertyAll(Color(0xFF21170F)),
        side: const BorderSide(color: textSecondary),
      ),
    );
  }

  static ThemeData get light {
    final base = dark;
    return base.copyWith(
      brightness: Brightness.light,
      scaffoldBackgroundColor: lightCanvas,
      canvasColor: lightCanvas,
      colorScheme: const ColorScheme.light(
        primary: warmBrown,
        onPrimary: Colors.white,
        secondary: gold,
        onSecondary: darkText,
        surface: lightSurface,
        onSurface: darkText,
        error: error,
        onError: Colors.white,
        outline: Color(0xFFD8CDBF),
      ),
      appBarTheme: const AppBarTheme(
        elevation: 0,
        scrolledUnderElevation: 0,
        backgroundColor: lightCanvas,
        foregroundColor: darkText,
        surfaceTintColor: Colors.transparent,
      ),
      cardTheme: const CardThemeData(
        elevation: 0,
        color: lightSurface,
        margin: EdgeInsets.zero,
        surfaceTintColor: Colors.transparent,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(18)),
          side: BorderSide(color: Color(0xFFD8CDBF)),
        ),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 70,
        backgroundColor: lightSurface,
        indicatorColor: gold.withValues(alpha: .20),
        labelTextStyle: WidgetStateProperty.resolveWith((states) => TextStyle(
          fontSize: 11,
          fontWeight: states.contains(WidgetState.selected) ? FontWeight.w800 : FontWeight.w600,
          color: states.contains(WidgetState.selected) ? warmBrown : const Color(0xFF776B61),
        )),
        iconTheme: WidgetStateProperty.resolveWith((states) => IconThemeData(
          color: states.contains(WidgetState.selected) ? warmBrown : const Color(0xFF776B61),
        )),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: lightSurface,
        labelStyle: const TextStyle(color: Color(0xFF776B61)),
        hintStyle: const TextStyle(color: Color(0xFF9B8F84)),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFD8CDBF)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: Color(0xFFD8CDBF)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: gold, width: 1.4),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
      textTheme: base.textTheme.apply(bodyColor: darkText, displayColor: darkText),
      dividerColor: const Color(0xFFD8CDBF),
    );
  }
}
