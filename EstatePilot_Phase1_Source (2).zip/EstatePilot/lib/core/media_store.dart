import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'native_bridge.dart';

/// Copies selected media into EstatePilot's app-private documents directory.
/// We never persist temporary picker/cache paths because Android may clean them.
class MediaStore {
  MediaStore._();
  static final ImagePicker _picker = ImagePicker();

  static Future<Directory> _folder(String propertyId, String type) async {
    final root = Directory(await NativeBridge.getDataPath());
    final safeId = propertyId.replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final dir = Directory(p.join(root.path, 'estatepilot_media', safeId, type));
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  static Future<String> _copyInto(String propertyId, String type, String sourcePath) async {
    final source = File(sourcePath);
    if (!await source.exists()) throw StateError('Selected file is no longer available');
    final dir = await _folder(propertyId, type);
    final ext = p.extension(source.path);
    final base = p.basenameWithoutExtension(source.path)
        .replaceAll(RegExp(r'[^A-Za-z0-9_-]'), '_');
    final target = File(p.join(dir.path, '${DateTime.now().millisecondsSinceEpoch}_$base$ext'));
    await source.copy(target.path);
    return target.path;
  }

  static Future<List<String>> pickImages(String propertyId) async {
    final files = await _picker.pickMultiImage(imageQuality: 88, maxWidth: 2200);
    final saved = <String>[];
    for (final item in files) {
      saved.add(await _copyInto(propertyId, 'images', item.path));
    }
    return saved;
  }

  static Future<String?> takePhoto(String propertyId) async {
    final file = await _picker.pickImage(source: ImageSource.camera, imageQuality: 88, maxWidth: 2200);
    if (file == null) return null;
    return _copyInto(propertyId, 'images', file.path);
  }

  static Future<String?> pickVideo(String propertyId) async {
    final file = await _picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return null;
    return _copyInto(propertyId, 'videos', file.path);
  }

  static Future<String?> recordVideo(String propertyId) async {
    final file = await _picker.pickVideo(source: ImageSource.camera, maxDuration: const Duration(minutes: 3));
    if (file == null) return null;
    return _copyInto(propertyId, 'videos', file.path);
  }

  static Future<List<String>> pickDocuments(String propertyId) async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true, withData: false);
    if (result == null) return const [];
    final saved = <String>[];
    for (final item in result.files) {
      if (item.path == null) continue;
      saved.add(await _copyInto(propertyId, 'documents', item.path!));
    }
    return saved;
  }

  static Future<void> deleteStoredFile(String path) async {
    try {
      final f = File(path);
      if (await f.exists()) await f.delete();
    } catch (_) {
      // Deleting an attachment should never corrupt the CRM record.
    }
  }
}
