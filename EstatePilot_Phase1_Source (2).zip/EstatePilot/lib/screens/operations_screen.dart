import 'package:flutter/material.dart';
import '../core/formatters.dart';
import '../core/native_bridge.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';

void _showError(BuildContext context, Object error) {
  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content:Text('$error'),backgroundColor:Colors.red.shade700));
}

Widget _empty(String text) => Padding(
  padding:const EdgeInsets.symmetric(vertical:36,horizontal:20),
  child:Center(child:Text(text,textAlign:TextAlign.center,
    style:const TextStyle(color:EstatePilotTheme.textSecondary,fontSize:15))));

Widget _section(String label) => Padding(
  padding:const EdgeInsets.fromLTRB(5,22,5,10),
  child:Text(label,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w800,
    color:EstatePilotTheme.warmBrown)));

Widget _field(TextEditingController c,String label,{TextInputType? keyboard,
  bool required=false,int lines=1}) => Padding(
  padding:const EdgeInsets.only(bottom:14),
  child:TextFormField(controller:c,maxLines:lines,keyboardType:keyboard,
    decoration:InputDecoration(labelText:label),validator:(v)=>
      required && (v==null || v.trim().isEmpty) ? '$label is required' : null));

Widget _dropdown(String label,String? current,List<String> choices,
  ValueChanged<String?> onChanged,{bool optional=false, Map<String,String>? labels}) => Padding(
  padding:const EdgeInsets.only(bottom:14),
  child:DropdownButtonFormField<String>(
    key:ValueKey('$label-$current'),
    initialValue:choices.contains(current)?current:null,
    isExpanded:true,decoration:InputDecoration(labelText:label),
    items:choices.map((v)=>DropdownMenuItem(value:v,child:Text(labels?[v]??v,
      overflow:TextOverflow.ellipsis))).toList(),onChanged:onChanged,
    validator:(value)=>!optional && (value==null || value.isEmpty)?'Select $label':null));

class OperationsHub extends StatelessWidget {
  const OperationsHub({super.key});
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    final entries=<({IconData icon,String name,String caption,Widget screen})>[
      (icon:Icons.auto_awesome_outlined,name:'Smart Property Matching',
        caption:'Rank available inventory for each buyer',screen:const MatchingScreen()),
      (icon:Icons.calendar_month_outlined,name:'Site Visits',
        caption:'Schedule visits and record client feedback',screen:const VisitsScreen()),
      (icon:Icons.handshake_outlined,name:'Deals & Commissions',
        caption:'Token, deal progress and commission balance',screen:const DealsScreen()),
      (icon:Icons.apartment_outlined,name:'Societies & Market Rates',
        caption:'B-17, FMC, Faisal Hills and your recorded rates',screen:const SocietiesScreen()),
      (icon:Icons.verified_user_outlined,name:'Property Verification',
        caption:'Record ownership, NOC and possession checks',screen:const VerificationScreen()),
      (icon:Icons.bar_chart_outlined,name:'Business Analytics',
        caption:'Inventory, conversion and financial overview',screen:const AnalyticsScreen()),
      (icon:Icons.backup_outlined,name:'Backup & Restore',
        caption:'Export or import your private CRM records',screen:const BackupScreen()),
    ];
    return Scaffold(appBar:AppBar(title:const Text('Business tools')),
      body:ListView(padding:const EdgeInsets.all(18),children:[
        Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(
          color:EstatePilotTheme.warmBrown,borderRadius:BorderRadius.circular(22)),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            const Text('ESTATEPILOT  •  OFFICE',style:TextStyle(
              color:EstatePilotTheme.gold,fontWeight:FontWeight.w900,letterSpacing:2)),
            const SizedBox(height:10),
            Text('${s.totalProperties} properties  •  ${s.clients.length} clients',
              style:const TextStyle(color:Colors.white,fontSize:19,fontWeight:FontWeight.w700)),
            const SizedBox(height:6),
            const Text('Your private, offline-first real estate operations',
              style:TextStyle(color:Colors.white70))
          ])),
        const SizedBox(height:16),
        ...entries.map((e)=>Padding(padding:const EdgeInsets.only(bottom:12),child:Card(
          child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:9),
            leading:CircleAvatar(backgroundColor:EstatePilotTheme.cream,
              child:Icon(e.icon,color:EstatePilotTheme.warmBrown)),
            title:Text(e.name,style:const TextStyle(fontWeight:FontWeight.w700)),
            subtitle:Text(e.caption),trailing:const Icon(Icons.chevron_right),
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>e.screen)))))),
      ]));
  }
}

class MatchingScreen extends StatefulWidget {
  const MatchingScreen({super.key});
  @override State<MatchingScreen> createState()=>_MatchingScreenState();
}
class _MatchingScreenState extends State<MatchingScreen> {
  String? buyerId;
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    final buyers=s.clients.where((c)=>c.roles.contains('Buyer')).toList();
    ClientModel? chosen;
    for (final c in buyers) { if (c.id == buyerId) { chosen = c; break; } }
    final matches=chosen==null?<PropertyMatch>[]:s.matchesFor(chosen);
    return Scaffold(appBar:AppBar(title:const Text('Smart Matching')),
      body:ListView(padding:const EdgeInsets.all(18),children:[
        const Text('Deterministic matching of stored buyer requirements and available properties. The score is an estimate, not an AI valuation.',
          style:TextStyle(color:EstatePilotTheme.textSecondary)),
        const SizedBox(height:16),
        if(buyers.isEmpty) _empty('Create a buyer profile with requirements first.')
        else _dropdown('Select buyer',buyerId,buyers.map((c)=>c.id).toList(),
          (v)=>setState(()=>buyerId=v),
          labels:{for(final c in buyers)c.id:c.name}),
        if(chosen!=null) ...[
          _section('Best available matches'),
          if(matches.isEmpty) _empty('No available properties in inventory.'),
          for(final m in matches) Padding(padding:const EdgeInsets.only(bottom:10),
            child:Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(
              crossAxisAlignment:CrossAxisAlignment.start,children:[
              Row(children:[
                Expanded(child:Text('${m.property.propertyId} · ${m.property.society}',
                  style:const TextStyle(fontWeight:FontWeight.w800,fontSize:16))),
                Text('${m.score}%',style:const TextStyle(fontWeight:FontWeight.w900,
                  fontSize:19,color:EstatePilotTheme.warmBrown))]),
              const SizedBox(height:6),
              Text('${m.property.block}  •  ${m.property.size}  •  ${formatPkr(m.property.displayPrice)}'),
              const Divider(height:24),
              ...m.reasons.map((r)=>Padding(padding:const EdgeInsets.only(bottom:4),
                child:Text(r,style:TextStyle(fontSize:12.5,color:r.startsWith('✓')?
                  const Color(0xFF157347):EstatePilotTheme.textSecondary)))),
              Align(alignment:Alignment.centerRight,child:TextButton.icon(
                onPressed:chosen.phone.trim().isEmpty?null:() async {
                  final selected = chosen!;
                  try {await NativeBridge.openWhatsApp(
                    selected.whatsapp.isNotEmpty?selected.whatsapp:selected.phone,
                    message:'Assalamualaikum ${selected.name}, here is a property option: '
                      '${m.property.propertyId}, ${m.property.displayLocation}, '
                      '${m.property.size}, ${formatPkr(m.property.displayPrice)}.');}
                  catch(e){if(context.mounted)_showError(context,e);}
                },icon:const Icon(Icons.send_outlined),label:const Text('Send option')))
            ]))))
        ]
      ]));
  }
}

class VisitsScreen extends StatelessWidget {
  const VisitsScreen({super.key});
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    final visits=[...s.siteVisits]..sort((a,b)=>a.scheduledAt.compareTo(b.scheduledAt));
    return Scaffold(appBar:AppBar(title:const Text('Site Visits')),
      floatingActionButton:FloatingActionButton.extended(
        onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const VisitForm())),
        icon:const Icon(Icons.add),label:const Text('Schedule visit')),
      body:visits.isEmpty?_empty('No site visits scheduled. Add the first visit.'):
        ListView.builder(padding:const EdgeInsets.fromLTRB(14,14,14,100),
          itemCount:visits.length,itemBuilder:(context,i){
            final v=visits[i];
            final c=s.clientById(v.clientId),p=s.propertyById(v.propertyId);
            return Padding(padding:const EdgeInsets.only(bottom:12),child:Card(
              child:ListTile(contentPadding:const EdgeInsets.all(14),
                leading:const CircleAvatar(child:Icon(Icons.location_on_outlined)),
                title:Text(c?.name??'Deleted client',style:const TextStyle(fontWeight:FontWeight.w700)),
                subtitle:Text('${p?.displayLocation??'Property unavailable'}\n'
                  '${formatDate(v.scheduledAt)} · ${formatTime(v.scheduledAt)}\n'
                  '${v.status}${v.outcome.isNotEmpty?' · ${v.outcome}':''}'),
                isThreeLine:true,trailing:const Icon(Icons.edit_note),
                onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>VisitForm(existing:v))))));
          }));
  }
}

class VisitForm extends StatefulWidget {
  const VisitForm({super.key,this.existing,this.initialClientId,this.initialPropertyId});
  final SiteVisitModel? existing;
  final String? initialClientId;
  final String? initialPropertyId;
  @override State<VisitForm> createState()=>_VisitFormState();
}
class _VisitFormState extends State<VisitForm> {
  final form=GlobalKey<FormState>();
  late String? clientId=widget.existing?.clientId ?? widget.initialClientId;
  late String? propertyId=widget.existing?.propertyId ?? widget.initialPropertyId;
  late DateTime when=widget.existing?.scheduledAt??DateTime.now().add(const Duration(days:1));
  late String status=widget.existing?.status??'Scheduled';
  late String outcome=widget.existing?.outcome??'Not recorded';
  late final note=TextEditingController(text:widget.existing?.notes??'');
  late final agent=TextEditingController(text:widget.existing?.assignedTo??'');
  bool saving=false;
  @override void dispose(){note.dispose();agent.dispose();super.dispose();}
  Future<void> chooseDate() async {
    final d=await showDatePicker(context:context,initialDate:when,
      firstDate:DateTime(2020),lastDate:DateTime(2100));
    if(d==null || !mounted)return;
    final t=await showTimePicker(context:context,initialTime:TimeOfDay.fromDateTime(when));
    if(t==null || !mounted)return;
    setState(()=>when=DateTime(d.year,d.month,d.day,t.hour,t.minute));
  }
  Future<void> save() async {
    if(!form.currentState!.validate())return;
    setState(()=>saving=true);
    final s=AppStateScope.of(context),now=DateTime.now();
    final v=SiteVisitModel(id:widget.existing?.id??newId('V'),
      clientId:clientId!,propertyId:propertyId!,scheduledAt:when,
      status:status,outcome:outcome=='Not recorded'?'':outcome,
      notes:note.text.trim(),assignedTo:agent.text.trim(),
      createdAt:widget.existing?.createdAt??now);
    try {
      if(widget.existing==null){await s.addSiteVisit(v);}else{await s.updateSiteVisit(v);}
      if(mounted)Navigator.pop(context);
    }catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    return Scaffold(appBar:AppBar(title:Text(widget.existing==null?'Schedule Visit':'Update Visit')),
      body:Form(key:form,child:ListView(padding:const EdgeInsets.all(18),children:[
        if(s.clients.isEmpty || s.properties.isEmpty) _empty('Add a client and a property first.'),
        _dropdown('Client',clientId,s.clients.map((e)=>e.id).toList(),
          (v)=>setState(()=>clientId=v),
          labels:{for(final c in s.clients)c.id:c.name}),
        if(clientId!=null) Text(s.clientById(clientId!)?.name??'',
          style:const TextStyle(fontWeight:FontWeight.w700)),
        const SizedBox(height:12),
        _dropdown('Property',propertyId,s.properties.where((e)=>e.status!='Archived').map((e)=>e.id).toList(),
          (v)=>setState(()=>propertyId=v),
          labels:{for(final p in s.properties)p.id:'${p.propertyId} • ${p.displayLocation}'}),
        if(propertyId!=null) Text(s.propertyById(propertyId!)?.displayLocation??'',
          style:const TextStyle(fontWeight:FontWeight.w700)),
        const SizedBox(height:12),
        OutlinedButton.icon(onPressed:chooseDate,icon:const Icon(Icons.calendar_month),
          label:Text('${formatDate(when)} · ${formatTime(when)}')),
        const SizedBox(height:12),
        _field(agent,'Assigned person'),_field(note,'Visit notes',lines:3),
        _dropdown('Status',status,const ['Scheduled','Completed','Cancelled','Rescheduled'],
          (v)=>setState(()=>status=v!)),
        _dropdown('Client response',outcome,const [
          'Not recorded','Interested','Very Interested','Negotiating',
          'Not Interested','Needs More Options'],(v)=>setState(()=>outcome=v!)),
        const SizedBox(height:20),
        FilledButton(onPressed:saving?null:save,
          child:Text(saving?'Saving...':'Save visit')),
      ])));
  }
}

class DealsScreen extends StatelessWidget {
  const DealsScreen({super.key});
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    return Scaffold(appBar:AppBar(title:const Text('Deals & Commission')),
      floatingActionButton:FloatingActionButton.extended(
        onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DealForm())),
        label:const Text('Add deal'),icon:const Icon(Icons.add)),
      body:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,110),children:[
        Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(
          crossAxisAlignment:CrossAxisAlignment.start,children:[
          const Text('Outstanding commission',style:TextStyle(color:EstatePilotTheme.textSecondary)),
          const SizedBox(height:6),
          Text(formatPkr(s.pendingCommission),style:const TextStyle(
            color:EstatePilotTheme.warmBrown,fontSize:25,fontWeight:FontWeight.w900)),
          Text('Total commission: ${formatPkr(s.totalCommission)}'),
        ]))),
        _section('Deal pipeline'),
        if(s.deals.isEmpty)_empty('No deals recorded. Add an actual deal to begin tracking.'),
        for(final d in s.deals) Padding(padding:const EdgeInsets.only(bottom:10),
          child:Card(child:ListTile(contentPadding:const EdgeInsets.all(14),
            title:Text('${s.propertyById(d.propertyId)?.propertyId??'Property'}  ·  ${d.status}',
              style:const TextStyle(fontWeight:FontWeight.w800)),
            subtitle:Text('Price: ${formatPkr(d.finalPrice)}\n'
              'Token: ${formatPkr(d.token)}  ·  Remaining: ${formatPkr(d.remainingAmount)}\n'
              'Commission: ${formatPkr(d.commissionTotal)}  ·  Pending: ${formatPkr(d.commissionPending)}'),
            isThreeLine:true,trailing:const Icon(Icons.edit_outlined),
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DealForm(existing:d)))))),
      ]));
  }
}

class DealForm extends StatefulWidget {
  const DealForm({super.key,this.existing});
  final DealModel? existing;
  @override State<DealForm> createState()=>_DealFormState();
}
class _DealFormState extends State<DealForm> {
  final form=GlobalKey<FormState>();
  late String? buyer=widget.existing?.buyerId;
  late String? seller=widget.existing?.sellerId;
  late String? property=widget.existing?.propertyId;
  late String status=widget.existing?.status??'Negotiation';
  late final price=TextEditingController(text:widget.existing?.finalPrice.toString()??'');
  late final token=TextEditingController(text:widget.existing?.token.toString()??'0');
  late final rate=TextEditingController(text:widget.existing?.commissionRate.toString()??'1');
  late final received=TextEditingController(text:widget.existing?.commissionReceived.toString()??'0');
  late final notes=TextEditingController(text:widget.existing?.notes??'');
  bool saving=false;
  @override void dispose(){for(final c in [price,token,rate,received,notes]){c.dispose();}super.dispose();}
  Future<void> save() async {
    if(!form.currentState!.validate())return;
    final s=AppStateScope.of(context);
    final finalPrice=double.tryParse(price.text.trim());
    final t=double.tryParse(token.text.trim()),r=double.tryParse(rate.text.trim());
    final paid=double.tryParse(received.text.trim());
    if(finalPrice==null || !finalPrice.isFinite || finalPrice<=0 ||
      t==null || !t.isFinite || t<0 || r==null || !r.isFinite || r<0 ||
      paid==null || !paid.isFinite || paid<0 || paid>finalPrice*r/100 || t>finalPrice){
      _showError(context,'Enter valid deal price, token and commission values');return;
    }
    final deal=DealModel(id:widget.existing?.id??newId('D'),buyerId:buyer!,
      sellerId:seller??'',propertyId:property!,finalPrice:finalPrice,
      token:t,commissionRate:r,commissionReceived:paid,status:status,
      notes:notes.text.trim(),dealDate:widget.existing?.dealDate??DateTime.now());
    setState(()=>saving=true);
    try {
      if(widget.existing==null){await s.addDeal(deal);}else{await s.updateDeal(deal);}
      if(mounted)Navigator.pop(context);
    }catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    final buyers=s.clients.where((c)=>c.roles.contains('Buyer')).toList();
    final sellers=s.clients.where((c)=>c.roles.contains('Seller / Owner')).toList();
    return Scaffold(appBar:AppBar(title:Text(widget.existing==null?'Create Deal':'Update Deal')),
      body:Form(key:form,child:ListView(padding:const EdgeInsets.all(18),children:[
        const Text('Deals link a real buyer and property. All monetary values are stored numerically in PKR.',
          style:TextStyle(color:EstatePilotTheme.textSecondary)),const SizedBox(height:18),
        _dropdown('Buyer',buyer,buyers.map((e)=>e.id).toList(),(v)=>setState(()=>buyer=v),
          labels:{for(final c in buyers)c.id:c.name}),
        if(buyer!=null)Text(s.clientById(buyer!)?.name??''),
        const SizedBox(height:8),
        if(sellers.isNotEmpty) ...[
          _dropdown('Seller / owner (optional)',seller,
            ['',...sellers.map((e)=>e.id)],(v)=>setState(()=>seller=v),optional:true,
            labels:{for(final c in sellers)c.id:c.name, '':'None / owner on property'}),
          if(seller!=null && seller!.isNotEmpty)Text(s.clientById(seller!)?.name??''),
        ],
        const SizedBox(height:8),
        _dropdown('Property',property,s.properties.where((p)=>p.status!='Archived').map((p)=>p.id).toList(),
          (v)=>setState(()=>property=v),
          labels:{for(final p in s.properties)p.id:'${p.propertyId} • ${p.displayLocation}'}),
        if(property!=null)Text(s.propertyById(property!)?.displayLocation??''),
        const SizedBox(height:14),
        _field(price,'Final deal price (Rs.)',keyboard:TextInputType.number,required:true),
        _field(token,'Token received (Rs.)',keyboard:TextInputType.number,required:true),
        _field(rate,'Commission (%)',keyboard:TextInputType.number,required:true),
        _field(received,'Commission received (Rs.)',keyboard:TextInputType.number,required:true),
        _dropdown('Deal status',status,const [
          'Negotiation','Token Received','Documentation','Transfer','Completed','Cancelled'],
          (v)=>setState(()=>status=v!)),
        _field(notes,'Deal notes',lines:3),const SizedBox(height:20),
        FilledButton(onPressed:saving?null:save,
          child:Text(saving?'Saving...':'Save deal')),
      ])));
  }
}

class SocietiesScreen extends StatelessWidget {
  const SocietiesScreen({super.key});
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    return Scaffold(appBar:AppBar(title:const Text('Societies & Market Rates')),
      floatingActionButton:FloatingActionButton.extended(
        onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const SocietyForm())),
        label:const Text('Add society'),icon:const Icon(Icons.add)),
      body:ListView(padding:const EdgeInsets.fromLTRB(16,16,16,110),children:[
        const Text('Market rates are recorded manually by you—not scraped or presented as live market data.',
          style:TextStyle(color:EstatePilotTheme.textSecondary)),
        _section('Societies'),
        for(final society in s.societies) Padding(padding:const EdgeInsets.only(bottom:10),
          child:Card(child:ListTile(contentPadding:const EdgeInsets.all(14),
            leading:const CircleAvatar(child:Icon(Icons.apartment)),
            title:Text(society.name,style:const TextStyle(fontWeight:FontWeight.w800)),
            subtitle:Text('${society.location}\n${society.blocks.isEmpty?'Blocks not added':society.blocks.join(', ')}'),
            isThreeLine:true,trailing:const Icon(Icons.edit_outlined),
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SocietyForm(existing:society)))))),
        const SizedBox(height:8),
        _section('Rate history'),
        OutlinedButton.icon(onPressed:()=>Navigator.push(context,
          MaterialPageRoute(builder:(_)=>const MarketRateForm())),
          icon:const Icon(Icons.add_chart),label:const Text('Record market rate')),
        if(s.marketRates.isEmpty) _empty('No rate entries. Rates will appear only when you record them.'),
        for(final rate in s.marketRates) Card(child:ListTile(
          title:Text('${rate.society}  •  ${rate.block}',
            style:const TextStyle(fontWeight:FontWeight.w800)),
          subtitle:Text('${rate.size} ${rate.propertyType}\n'
            'Asking: ${formatPkr(rate.askingRate)} · Deal: ${formatPkr(rate.dealRate)}\n'
            '${formatDate(rate.recordedAt)} · ${rate.source}',
            maxLines:4),isThreeLine:true)),
      ]));
  }
}

class SocietyForm extends StatefulWidget {
  const SocietyForm({super.key,this.existing});
  final SocietyModel? existing;
  @override State<SocietyForm> createState()=>_SocietyFormState();
}
class _SocietyFormState extends State<SocietyForm> {
  final form=GlobalKey<FormState>();
  late final name=TextEditingController(text:widget.existing?.name??'');
  late final location=TextEditingController(text:widget.existing?.location??'');
  late final blocks=TextEditingController(text:widget.existing?.blocks.join(', ')??'');
  late final notes=TextEditingController(text:widget.existing?.notes??'');
  bool saving=false;
  @override void dispose(){for(final c in [name,location,blocks,notes]){c.dispose();}super.dispose();}
  Future<void> save() async {
    if(!form.currentState!.validate())return;
    final s=AppStateScope.of(context);
    final model=SocietyModel(id:widget.existing?.id??newId('S'),
      name:name.text.trim(),location:location.text.trim(),
      blocks:blocks.text.split(',').map((b)=>b.trim()).where((b)=>b.isNotEmpty).toSet().toList(),
      notes:notes.text.trim());
    setState(()=>saving=true);
    try{await s.upsertSociety(model);if(mounted)Navigator.pop(context);}
    catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.existing==null?'Add Society':'Edit Society')),
    body:Form(key:form,child:ListView(padding:const EdgeInsets.all(18),children:[
      _field(name,'Society name',required:true),_field(location,'Location'),
      _field(blocks,'Blocks (separated by commas)',lines:3),
      _field(notes,'Society notes',lines:3),
      FilledButton(onPressed:saving?null:save,child:Text(saving?'Saving...':'Save society')),
    ])));
}

class MarketRateForm extends StatefulWidget {
  const MarketRateForm({super.key});
  @override State<MarketRateForm> createState()=>_MarketRateFormState();
}
class _MarketRateFormState extends State<MarketRateForm> {
  final form=GlobalKey<FormState>();
  String? society;
  final block=TextEditingController(),size=TextEditingController(),
    type=TextEditingController(text:'Residential Plot'),
    asking=TextEditingController(),deal=TextEditingController(),
    source=TextEditingController(),notes=TextEditingController();
  bool saving=false;
  @override void dispose(){for(final c in [block,size,type,asking,deal,source,notes]){c.dispose();}super.dispose();}
  Future<void> save() async {
    if(!form.currentState!.validate())return;
    final a=double.tryParse(asking.text.trim()),d=double.tryParse(deal.text.trim());
    if(a==null || d==null || !a.isFinite || !d.isFinite || a<0 || d<0){_showError(context,'Enter valid positive rate amounts');return;}
    final s=AppStateScope.of(context);
    final rate=MarketRateModel(id:newId('R'),society:society!,block:block.text.trim(),
      size:size.text.trim(),propertyType:type.text.trim(),askingRate:a,dealRate:d,
      recordedAt:DateTime.now(),source:source.text.trim(),notes:notes.text.trim());
    setState(()=>saving=true);
    try{await s.addMarketRate(rate);if(mounted)Navigator.pop(context);}
    catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    return Scaffold(appBar:AppBar(title:const Text('Record Market Rate')),
      body:Form(key:form,child:ListView(padding:const EdgeInsets.all(18),children:[
        _dropdown('Society',society,s.societies.map((e)=>e.name).toList(),
          (v)=>setState(()=>society=v)),
        _field(block,'Block',required:true),_field(size,'Size (e.g. 5 Marla)',required:true),
        _field(type,'Property type',required:true),
        _field(asking,'Asking rate (Rs.)',keyboard:TextInputType.number,required:true),
        _field(deal,'Deal rate (Rs.)',keyboard:TextInputType.number,required:true),
        _field(source,'Source / dealer name'),_field(notes,'Notes',lines:2),
        FilledButton(onPressed:saving?null:save,child:Text(saving?'Saving...':'Record rate')),
      ])));
  }
}

const verificationLabels=<String>[
  'Ownership checked','Owner identity verified','Documents checked',
  'NOC checked','Possession confirmed','Utilities checked',
  'Location checked','Price checked'
];

class VerificationScreen extends StatefulWidget {
  const VerificationScreen({super.key});
  @override State<VerificationScreen> createState()=>_VerificationScreenState();
}
class _VerificationScreenState extends State<VerificationScreen> {
  String? selectedProperty;
  Map<String,bool> checks={};
  final notes=TextEditingController();
  bool saving=false;
  @override void dispose(){notes.dispose();super.dispose();}
  void select(String? id,AppState s) {
    final v=id==null?null:s.verificationByProperty(id);
    setState((){
      selectedProperty=id;
      checks={for(final label in verificationLabels)label:v?.checks[label]??false};
      notes.text=v?.notes??'';
    });
  }
  Future<void> save() async {
    if(selectedProperty==null)return;
    final s=AppStateScope.of(context);
    final existing=s.verificationByProperty(selectedProperty!);
    final value=VerificationModel(id:existing?.id??newId('VR'),
      propertyId:selectedProperty!,checks:Map.from(checks),
      notes:notes.text.trim(),checkedAt:DateTime.now());
    setState(()=>saving=true);
    try {
      await s.upsertVerification(value);
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content:Text('Verification checklist saved')));
    }catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>saving=false);}
  }
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    return Scaffold(appBar:AppBar(title:const Text('Property Verification')),
      body:ListView(padding:const EdgeInsets.all(18),children:[
        const Text('This is an internal verification checklist. Ticking an item does not constitute official legal verification.',
          style:TextStyle(color:EstatePilotTheme.textSecondary)),
        const SizedBox(height:20),
        _dropdown('Select property',selectedProperty,
          s.properties.where((p)=>p.status!='Archived').map((p)=>p.id).toList(),
          (v)=>select(v,s),
          labels:{for(final p in s.properties)p.id:'${p.propertyId} • ${p.displayLocation}'}),
        if(selectedProperty!=null)...[
          Text(s.propertyById(selectedProperty!)?.displayLocation??'',
            style:const TextStyle(fontWeight:FontWeight.w700)),
          _section('Document and location checks'),
          for(final label in verificationLabels)CheckboxListTile(
            title:Text(label),value:checks[label]??false,
            onChanged:(v)=>setState(()=>checks[label]=v??false)),
          const SizedBox(height:10),
          _field(notes,'Verification notes',lines:3),
          FilledButton(onPressed:saving?null:save,
            child:Text(saving?'Saving...':'Save checklist')),
        ]
      ]));
  }
}

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});
  @override Widget build(BuildContext context) {
    final s=AppStateScope.of(context);
    final percentage=s.leads.isEmpty?0:100*s.completedDeals/s.leads.length;
    final rows=<({String label,String value})>[
      (label:'Total inventory',value:'${s.totalProperties}'),
      (label:'Available properties',value:'${s.countPropertyStatus('Available')}'),
      (label:'Sold properties',value:'${s.countPropertyStatus('Sold')}'),
      (label:'Buyers',value:'${s.buyers}'),
      (label:'Owners',value:'${s.sellers}'),
      (label:'Active leads',value:'${s.activeLeads}'),
      (label:'Site visits',value:'${s.siteVisits.length}'),
      (label:'Deals completed',value:'${s.completedDeals}'),
      (label:'Commission total',value:formatPkr(s.totalCommission)),
      (label:'Commission pending',value:formatPkr(s.pendingCommission)),
      (label:'Closed deals / leads',value:'${percentage.toStringAsFixed(1)}%'),
    ];
    return Scaffold(appBar:AppBar(title:const Text('Business Analytics')),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        const Text('Calculated from your own saved records only. No invented sales or live market feeds.',
          style:TextStyle(color:EstatePilotTheme.textSecondary)),
        _section('Business snapshot'),
        for(final row in rows) Card(child:ListTile(title:Text(row.label),
          trailing:Text(row.value,style:const TextStyle(fontSize:16,
            fontWeight:FontWeight.w800,color:EstatePilotTheme.warmBrown)))),
      ]));
  }
}

class BackupScreen extends StatefulWidget {
  const BackupScreen({super.key});
  @override State<BackupScreen> createState()=>_BackupScreenState();
}
class _BackupScreenState extends State<BackupScreen> {
  bool busy=false;
  Future<void> export() async {
    final s=AppStateScope.of(context);
    setState(()=>busy=true);
    try {
      final ok=await s.exportBackup();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:Text(ok?'CRM backup saved to selected location':'Backup cancelled')));
    }catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>busy=false);}
  }
  Future<void> restore() async {
    final confirmed=await showDialog<bool>(context:context,
      builder:(ctx)=>AlertDialog(title:const Text('Replace all current data?'),
        content:const Text('Restore REPLACES every existing property, client, deal, and follow-up. Export a backup first. Continue?'),
        actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancel')),
          FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Replace data'))]));
    if(confirmed!=true || !mounted)return;
    final s=AppStateScope.of(context);
    setState(()=>busy=true);
    try {
      final ok=await s.restoreBackup();
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:Text(ok?'Data successfully restored':'Restore cancelled')));
    }catch(e){if(mounted)_showError(context,e);}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Backup & Restore')),
    body:ListView(padding:const EdgeInsets.all(20),children:[
      const Icon(Icons.shield_outlined,size:55,color:EstatePilotTheme.warmBrown),
      _section('Your data stays on your device'),
      const Text('EstatePilot saves business records in the Android app-private SQLite database. Data survives normal app restarts and phone reboots. Uninstalling the app can erase this database.'),
      const SizedBox(height:14),
      const Text('Important: exported JSON contains client phone numbers and financial information in plain text. Property photos/videos/documents remain in app-private storage and are not packaged into this JSON backup yet. Store the backup securely.',
        style:TextStyle(color:Color(0xFF9A3412),fontWeight:FontWeight.w600)),
      const SizedBox(height:24),
      FilledButton.icon(onPressed:busy?null:export,icon:const Icon(Icons.file_download_outlined),
        label:const Text('Export CRM backup')),
      const SizedBox(height:14),
      OutlinedButton.icon(onPressed:busy?null:restore,icon:const Icon(Icons.restore_outlined),
        label:const Text('Restore from backup file')),
    ]));
}
