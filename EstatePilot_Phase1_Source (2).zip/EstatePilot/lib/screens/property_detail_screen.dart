import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:open_filex/open_filex.dart';

import '../core/formatters.dart';
import '../core/native_bridge.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'operations_screen.dart';
import 'property_form_screen.dart';

class PropertyDetailScreen extends StatelessWidget {
  const PropertyDetailScreen({super.key, required this.propertyId});
  final String propertyId;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final property = state.propertyById(propertyId);
    if (property == null) return const Scaffold(body: Center(child: Text('Property not found.')));

    return Scaffold(
      appBar: AppBar(
        title: Text(property.propertyId),
        actions: [
          IconButton(
            tooltip: 'Edit property',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyFormScreen(initial: property))),
            icon: const Icon(Icons.edit_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          _hero(context, property),
          const SizedBox(height: 12),
          _quickActions(context, state, property),
          if (property.imagePaths.isNotEmpty) ...[
            const SizedBox(height: 16),
            _gallery(property),
          ],
          const SizedBox(height: 16),
          _section(context, 'Property identity', [
            _row(context, 'Property ID', property.propertyId),
            _row(context, 'Reference No.', property.referenceNo),
            _row(context, 'Society', property.society),
            _row(context, 'Block / Sector', [property.block, property.sector].where((e)=>e.isNotEmpty).join(' • ')),
            _row(context, 'Street / Plot', [property.street, property.plotNumber].where((e)=>e.isNotEmpty).join(' • ')),
            _row(context, 'Type', property.type),
            _row(context, 'Size', '${property.size} ${property.unit}'),
            _row(context, 'Purpose', property.purpose),
            _row(context, 'Status', property.status, trailing: StatusBadge(property.status)),
          ]),
          _section(context, 'Features & location', [
            _row(context, 'Road width', property.roadWidth),
            _row(context, 'Facing', property.facing),
            _chips(property),
            if (property.locationNotes.isNotEmpty) Text(property.locationNotes, style: const TextStyle(height: 1.45)),
          ]),
          _section(context, 'Financial information', [
            _moneyRow(context, 'Owner demand', property.ownerDemand),
            _moneyRow(context, 'Asking price', property.askingPrice),
            _moneyRow(context, 'Expected deal price', property.expectedDealPrice),
            _moneyRow(context, 'Minimum price', property.minimumPrice),
            if (property.status == 'Sold' || property.salePrice > 0) _moneyRow(context, 'Final sale price', property.salePrice),
            _moneyRow(context, 'Commission', property.commission),
            _moneyRow(context, 'Token', property.tokenAmount),
            _moneyRow(context, 'Remaining', property.remainingAmount),
            _row(context, 'Payment terms', property.paymentTerms),
            _row(context, 'Installments', property.installmentAvailable ? 'Available' : 'No'),
          ]),
          _section(context, 'Owner & source trail', [
            _row(context, 'Owner', property.ownerName),
            _row(context, 'Owner phone', property.ownerPhone),
            _row(context, 'Source', property.source),
            _row(context, 'Source contact', property.sourceContact),
            _row(context, 'Source detail', property.sourceDetail),
          ]),
          if (property.videoPaths.isNotEmpty || property.documentPaths.isNotEmpty)
            _section(context, 'Attachments', [
              if (property.videoPaths.isNotEmpty) ...[
                const Text('Videos', style: TextStyle(fontWeight: FontWeight.w800)),
                ...property.videoPaths.map((e)=>_fileRow(Icons.videocam_outlined,e)),
              ],
              if (property.documentPaths.isNotEmpty) ...[
                const Text('Documents', style: TextStyle(fontWeight: FontWeight.w800)),
                ...property.documentPaths.map((e)=>_fileRow(Icons.description_outlined,e)),
              ],
            ]),
          _section(context, 'Notes', [
            Text(property.notes.isEmpty ? 'No notes added.' : property.notes, style: const TextStyle(height: 1.45)),
          ]),
          _section(context, 'Record history', [
            _row(context, 'Created', formatDate(property.createdAt)),
            _row(context, 'Last updated', '${formatDate(property.updatedAt)} • ${formatTime(property.updatedAt)}'),
            if (property.soldAt != null) _row(context, 'Sold on', '${formatDate(property.soldAt!)} • ${formatTime(property.soldAt!)}'),
            if (property.history.isEmpty)
              const Text('No detailed history recorded yet.', style: TextStyle(color: EstatePilotTheme.textSecondary))
            else
              ...property.history.reversed.take(30).map((entry)=>Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Icon(Icons.history, size: 16, color: EstatePilotTheme.gold),
                  const SizedBox(width: 8),
                  Expanded(child: Text(entry, style: const TextStyle(fontSize: 12.5, color: EstatePilotTheme.textSecondary))),
                ]),
              )),
          ]),
        ],
      ),
    );
  }

  Widget _hero(BuildContext context, PropertyModel property) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: EstatePilotTheme.surface,
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: EstatePilotTheme.divider),
    ),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        Expanded(child: Text(property.displayLocation.isEmpty ? property.propertyId : property.displayLocation,
          style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900))),
        StatusBadge(property.status),
      ]),
      const SizedBox(height: 8),
      Text('${property.size} ${property.unit} • ${property.type}', style: const TextStyle(color: EstatePilotTheme.textSecondary)),
      const SizedBox(height: 18),
      Text(formatPkr(property.displayPrice), style: const TextStyle(color: EstatePilotTheme.lightGold, fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 3),
      Text(property.status == 'Sold' ? 'Recorded sale value' : 'Expected / asking value', style: const TextStyle(fontSize: 11, color: EstatePilotTheme.textSecondary)),
    ]),
  );

  Widget _quickActions(BuildContext context, AppState state, PropertyModel property) {
    final whatsapp = property.ownerPhone;
    final buttons = <Widget>[
      _action(Icons.call_outlined,'Call',whatsapp.isEmpty?null:()=>NativeBridge.openDialer(whatsapp)),
      _action(Icons.chat_outlined,'WhatsApp',whatsapp.isEmpty?null:()=>NativeBridge.openWhatsApp(whatsapp,
        message:'Assalamualaikum, regarding ${property.propertyId} (${property.displayLocation}).')),
      _action(Icons.share_outlined,'Share',()=>NativeBridge.shareText(_shareText(property))),
      _action(Icons.event_available_outlined,'Visit',()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>VisitForm(initialPropertyId:property.id)))),
    ];
    return Column(children:[
      Row(children:[for(var i=0;i<buttons.length;i++)...[Expanded(child:buttons[i]),if(i<buttons.length-1)const SizedBox(width:6)]]),
      const SizedBox(height:8),
      Row(children:[
        if(property.status!='Sold') Expanded(child:OutlinedButton.icon(
          onPressed:()=>_markSold(context,state,property),icon:const Icon(Icons.handshake_outlined),label:const Text('Mark Sold'))),
        if(property.status!='Sold') const SizedBox(width:8),
        Expanded(child:OutlinedButton.icon(
          style:OutlinedButton.styleFrom(foregroundColor:EstatePilotTheme.error),
          onPressed:property.status=='Archived'?null:()=>_archive(context,state,property),
          icon:const Icon(Icons.archive_outlined),label:Text(property.status=='Archived'?'Archived':'Archive'))),
      ]),
    ]);
  }

  Future<void> _markSold(BuildContext context, AppState state, PropertyModel property) async {
    final controller=TextEditingController(text:property.salePrice>0?property.salePrice.toStringAsFixed(0):'');
    final result=await showDialog<double>(context:context,builder:(context)=>AlertDialog(
      title:const Text('Mark property as sold'),content:TextField(controller:controller,keyboardType:TextInputType.number,
        decoration:const InputDecoration(labelText:'Final Sale Price',prefixText:'Rs. ')),actions:[
          TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),
          FilledButton(onPressed:()=>Navigator.pop(context,double.tryParse(controller.text.replaceAll(',',''))??0),child:const Text('Mark Sold')),
        ]));
    controller.dispose();
    if(result==null)return;
    await state.markPropertySold(property.id,salePrice:result);
  }

  Future<void> _archive(BuildContext context,AppState state,PropertyModel property) async {
    if(!await confirmDialog(context,title:'Archive property?',message:'This removes the property from active inventory but keeps the complete record and history.',confirmText:'Archive',destructive:true))return;
    await state.archiveProperty(property.id);
  }

  String _shareText(PropertyModel p)=>'EstatePilot Property\n${p.propertyId} | Ref: ${p.referenceNo}\n${p.displayLocation}\n${p.size} ${p.unit} ${p.type}\nPrice: ${formatPkr(p.displayPrice)}\nStatus: ${p.status}';

  Widget _action(IconData icon,String label,VoidCallback? onTap)=>OutlinedButton(onPressed:onTap,
    child:Padding(padding:const EdgeInsets.symmetric(vertical:4),child:Column(children:[Icon(icon,size:19),const SizedBox(height:4),Text(label,style:const TextStyle(fontSize:10.5,fontWeight:FontWeight.w700))])));

  Widget _gallery(PropertyModel property)=>SizedBox(height:190,child:ListView.separated(scrollDirection:Axis.horizontal,itemCount:property.imagePaths.length,separatorBuilder:(_,__)=>const SizedBox(width:10),itemBuilder:(context,i){
    final file=File(property.imagePaths[i]);
    return ClipRRect(borderRadius:BorderRadius.circular(18),child:Container(width:270,color:EstatePilotTheme.surface,
      child:file.existsSync()?Image.file(file,fit:BoxFit.cover):const Center(child:Icon(Icons.broken_image_outlined,size:40))));
  }));

  Widget _chips(PropertyModel p){
    final labels=<String>[];
    if(p.corner)labels.add('Corner');if(p.parkFacing)labels.add('Park Facing');if(p.mainRoad)labels.add('Main Road');if(p.possession)labels.add('Possession');
    if(p.electricity)labels.add('Electricity');if(p.gas)labels.add('Gas');if(p.water)labels.add('Water');if(p.sewerage)labels.add('Sewerage');
    if(p.negotiable)labels.add('Negotiable');if(p.urgentSale)labels.add('Urgent');
    return labels.isEmpty?const Text('No feature flags recorded.',style:TextStyle(color:EstatePilotTheme.textSecondary)):
      Wrap(spacing:6,runSpacing:6,children:labels.map((e)=>Chip(label:Text(e))).toList());
  }

  Widget _section(BuildContext context,String title,List<Widget> children)=>Card(margin:const EdgeInsets.only(bottom:12),child:Padding(
    padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(title,style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:12),
      for(var i=0;i<children.length;i++)...[children[i],if(i<children.length-1)const Divider(height:20)],
    ])));

  Widget _row(BuildContext context,String label,String value,{Widget? trailing})=>Row(crossAxisAlignment:CrossAxisAlignment.start,children:[
    SizedBox(width:116,child:Text(label,style:const TextStyle(fontSize:12,color:EstatePilotTheme.textSecondary,fontWeight:FontWeight.w600))),
    Expanded(child:Text(value.trim().isEmpty?'—':value,style:const TextStyle(fontSize:13,fontWeight:FontWeight.w700))),
    if(trailing!=null)...[const SizedBox(width:8),trailing],
  ]);

  Widget _moneyRow(BuildContext context,String label,double value)=>_row(context,label,value<=0?'—':formatPkr(value));

  Widget _fileRow(IconData icon,String path)=>Padding(padding:const EdgeInsets.symmetric(vertical:4),child:InkWell(
    borderRadius:BorderRadius.circular(10),onTap:()=>OpenFilex.open(path),child:Padding(padding:const EdgeInsets.symmetric(vertical:7,horizontal:6),child:Row(children:[
      Icon(icon,color:EstatePilotTheme.gold,size:20),const SizedBox(width:9),Expanded(child:Text(p.basename(path),maxLines:1,overflow:TextOverflow.ellipsis)),
      const Icon(Icons.open_in_new,size:17,color:EstatePilotTheme.textSecondary),
    ]))));
}
