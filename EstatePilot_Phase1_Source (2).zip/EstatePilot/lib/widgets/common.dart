import 'package:flutter/material.dart';

import '../core/theme.dart';

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title,{super.key,this.trailing});
  final String title;
  final Widget? trailing;
  @override Widget build(BuildContext context)=>Row(children:[
    Expanded(child:Text(title,style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w900))),
    if(trailing!=null)trailing!,
  ]);
}

class EmptyState extends StatelessWidget {
  const EmptyState({super.key,required this.icon,required this.title,required this.message,this.actionLabel,this.onAction});
  final IconData icon; final String title,message; final String? actionLabel; final VoidCallback? onAction;
  @override Widget build(BuildContext context)=>Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[
    Container(width:70,height:70,decoration:BoxDecoration(color:EstatePilotTheme.gold.withValues(alpha:.10),borderRadius:BorderRadius.circular(22),border:Border.all(color:EstatePilotTheme.gold.withValues(alpha:.25))),child:Icon(icon,size:34,color:EstatePilotTheme.gold)),
    const SizedBox(height:18),Text(title,style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.w900)),
    const SizedBox(height:6),Text(message,textAlign:TextAlign.center,style:const TextStyle(color:EstatePilotTheme.textSecondary,height:1.35)),
    if(onAction!=null&&actionLabel!=null)...[const SizedBox(height:18),FilledButton.icon(onPressed:onAction,icon:const Icon(Icons.add),label:Text(actionLabel!))],
  ])));
}

class StatusBadge extends StatelessWidget {
  const StatusBadge(this.text,{super.key});
  final String text;
  Color _color(){
    switch(text.toLowerCase()){
      case 'available': case 'active': case 'completed': case 'deal closed': return EstatePilotTheme.success;
      case 'sold': case 'lost': case 'cancelled': case 'archived': return EstatePilotTheme.error;
      case 'reserved': case 'hold': case 'warm': case 'negotiation': return EstatePilotTheme.warning;
      case 'hot': case 'overdue': return const Color(0xFFB7665D);
      case 'cold': return const Color(0xFF7F8A8A);
      default:return EstatePilotTheme.gold;
    }
  }
  @override Widget build(BuildContext context){final color=_color();return Container(padding:const EdgeInsets.symmetric(horizontal:9,vertical:5),decoration:BoxDecoration(color:color.withValues(alpha:.12),borderRadius:BorderRadius.circular(999),border:Border.all(color:color.withValues(alpha:.24))),child:Text(text,style:TextStyle(fontSize:10.5,fontWeight:FontWeight.w800,color:color)));}
}

class MetricCard extends StatelessWidget {
  const MetricCard({super.key,required this.label,required this.value,required this.icon,this.highlight=false,this.onTap});
  final String label,value;final IconData icon;final bool highlight;final VoidCallback? onTap;
  @override Widget build(BuildContext context){
    final body=Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(
      color:highlight?EstatePilotTheme.deepBrown:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(18),
      border:Border.all(color:highlight?EstatePilotTheme.gold.withValues(alpha:.45):EstatePilotTheme.divider)),
      child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Container(width:34,height:34,decoration:BoxDecoration(color:EstatePilotTheme.gold.withValues(alpha:.10),borderRadius:BorderRadius.circular(11)),child:Icon(icon,size:18,color:EstatePilotTheme.gold)),
        const Spacer(),Text(value,maxLines:1,overflow:TextOverflow.ellipsis,style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w900,color:highlight?EstatePilotTheme.lightGold:null)),
        const SizedBox(height:3),Text(label,maxLines:2,overflow:TextOverflow.ellipsis,style:const TextStyle(fontSize:11.5,fontWeight:FontWeight.w600,color:EstatePilotTheme.textSecondary)),
      ]));
    return onTap==null?body:InkWell(borderRadius:BorderRadius.circular(18),onTap:onTap,child:body);
  }
}

class LuxuryPanel extends StatelessWidget {
  const LuxuryPanel({super.key,required this.child,this.padding=const EdgeInsets.all(16),this.goldEdge=false});
  final Widget child;final EdgeInsets padding;final bool goldEdge;
  @override Widget build(BuildContext context)=>Container(padding:padding,decoration:BoxDecoration(color:EstatePilotTheme.surface,borderRadius:BorderRadius.circular(18),border:Border.all(color:goldEdge?EstatePilotTheme.gold.withValues(alpha:.42):EstatePilotTheme.divider)),child:child);
}

Future<bool> confirmDialog(BuildContext context,{required String title,required String message,String confirmText='Confirm',bool destructive=false})async{
  final result=await showDialog<bool>(context:context,builder:(context)=>AlertDialog(title:Text(title),content:Text(message),actions:[
    TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),
    FilledButton(style:destructive?FilledButton.styleFrom(backgroundColor:EstatePilotTheme.error,foregroundColor:Colors.white):null,onPressed:()=>Navigator.pop(context,true),child:Text(confirmText)),
  ]));
  return result??false;
}
