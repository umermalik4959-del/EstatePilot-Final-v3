import 'dart:async';
import 'package:flutter/material.dart';
import '../data/local_store.dart';
import '../data/models.dart';

class PropertyMatch {
  const PropertyMatch(this.property, this.score, this.reasons);
  final PropertyModel property;
  final int score;
  final List<String> reasons;
}

class AppState extends ChangeNotifier {
  AppState(this._store);
  final LocalStore _store;
  EstatePilotDatabase _db = EstatePilotDatabase();
  bool _ready = false;
  String? _lastError;
  String? _loadFailure;
  Future<void> _pending = Future.value();

  bool get ready => _ready;
  String? get lastError => _lastError;
  String? get loadFailure => _loadFailure;
  List<PropertyModel> get properties => List.unmodifiable(_db.properties);
  List<ClientModel> get clients => List.unmodifiable(_db.clients);
  List<LeadModel> get leads => List.unmodifiable(_db.leads);
  List<FollowUpModel> get followUps => List.unmodifiable(_db.followUps);
  List<SiteVisitModel> get siteVisits => List.unmodifiable(_db.siteVisits);
  List<DealModel> get deals => List.unmodifiable(_db.deals);
  List<SocietyModel> get societies => List.unmodifiable(_db.societies);
  List<MarketRateModel> get marketRates => List.unmodifiable(_db.marketRates);
  List<VerificationModel> get verifications => List.unmodifiable(_db.verifications);
  AppSettingsModel get settings => _db.appSettings.isEmpty
      ? const AppSettingsModel(id:'APP-SETTINGS',profileName:'',profilePhone:'',currency:'PKR',dateFormat:'dd MMM yyyy',defaultSociety:'B-17',defaultPropertyView:'Active',themeMode:'dark')
      : _db.appSettings.first;
  List<ActivityModel> get activities {
    final list = [..._db.activities]..sort((a,b)=>b.createdAt.compareTo(a.createdAt));
    return List.unmodifiable(list);
  }

  Future<void> initialize() async {
    try {
      _db = await _store.load();
      var seeded = false;
      if (_db.societies.isEmpty) {
        _db.societies.addAll(const [
          SocietyModel(id: 'SOC-B17', name: 'B-17 Multi Gardens', location: 'Islamabad', blocks: [], notes: ''),
          SocietyModel(id: 'SOC-FMC', name: 'Faisal Margalla City', location: 'Islamabad', blocks: [], notes: ''),
          SocietyModel(id: 'SOC-FH', name: 'Faisal Hills', location: 'Taxila', blocks: [], notes: ''),
        ]);
        seeded = true;
      }
      if (_db.appSettings.isEmpty) {
        _db.appSettings.add(const AppSettingsModel(
          id:'APP-SETTINGS',profileName:'',profilePhone:'',currency:'PKR',
          dateFormat:'dd MMM yyyy',defaultSociety:'B-17',
          defaultPropertyView:'Active',themeMode:'dark'));
        seeded = true;
      }
      if (seeded) await _store.save(_db);
      _loadFailure = null;
      _lastError = null;
    } catch (error) {
      // Safety: do NOT create a new empty database over potentially recoverable
      // customer data when an existing SQLite file cannot be loaded.
      _loadFailure = 'Cannot safely open stored CRM data: $error';
      _lastError = _loadFailure;
    }
    _ready = true;
    notifyListeners();
  }

  /// Mutations serialize; the UI only changes after the SQLite transaction
  /// commits. A write error never presents unsaved data as saved.
  Future<void> _mutate(void Function(EstatePilotDatabase) change) {
    final completer = Completer<void>();
    _pending = _pending.then((_) async {
      if (_loadFailure != null) throw StateError(_loadFailure!);
      final next = EstatePilotDatabase.fromJson(_db.toJson());
      change(next);
      await _store.save(next);
      _db = next;
      _lastError = null;
      notifyListeners();
    }).then((_) => completer.complete()).catchError((Object error, StackTrace stack) {
      _lastError = 'Data was not saved: $error';
      notifyListeners();
      completer.completeError(error, stack);
    });
    return completer.future;
  }

  int get totalProperties => _db.properties.where((p)=>p.status!='Archived').length;
  int get activeProperties => _db.properties.where((p)=>!['Archived','Sold','Rented','Unavailable'].contains(p.status)).length;
  int get soldProperties => _db.properties.where((p)=>p.status=='Sold').length;
  int get upcomingSiteVisits => _db.siteVisits.where((v)=>v.status=='Scheduled' && v.scheduledAt.isAfter(DateTime.now().subtract(const Duration(minutes:1)))).length;
  int countPropertyStatus(String status) => _db.properties.where((p)=>p.status==status).length;
  int get activeLeads => _db.leads.where((l)=>l.stage!='Deal Closed' && l.stage!='Lost').length;
  int get buyers => _db.clients.where((c)=>c.roles.contains('Buyer')).length;
  int get sellers => _db.clients.where((c)=>c.roles.contains('Seller / Owner')).length;
  int get pendingFollowUps => _db.followUps.where((f)=>!f.isCompleted).length;
  int get completedDeals => _db.deals.where((d)=>d.status=='Completed').length;
  double get totalCommission => _db.deals.where((d)=>d.status!='Cancelled')
      .fold(0.0,(sum,d)=>sum + d.commissionTotal);
  double get pendingCommission => _db.deals.where((d)=>d.status!='Cancelled')
      .fold(0.0,(sum,d)=>sum + d.commissionPending);

  static bool _sameDay(DateTime a, DateTime b) =>
    a.year==b.year && a.month==b.month && a.day==b.day;
  List<FollowUpModel> get todayFollowUps => _db.followUps.where((f)=>
      !f.isCompleted && _sameDay(f.scheduledAt,DateTime.now())).toList()
    ..sort((a,b)=>a.scheduledAt.compareTo(b.scheduledAt));
  List<FollowUpModel> get overdueFollowUps => _db.followUps.where((f)=>
      !f.isCompleted && f.scheduledAt.isBefore(DateTime.now()) &&
      !_sameDay(f.scheduledAt,DateTime.now())).toList()
    ..sort((a,b)=>a.scheduledAt.compareTo(b.scheduledAt));
  List<FollowUpModel> get upcomingFollowUps => _db.followUps.where((f)=>
      !f.isCompleted && f.scheduledAt.isAfter(DateTime.now()) &&
      !_sameDay(f.scheduledAt,DateTime.now())).toList()
    ..sort((a,b)=>a.scheduledAt.compareTo(b.scheduledAt));

  void _activity(EstatePilotDatabase db,String title,String subtitle,String kind) {
    db.activities.add(ActivityModel(id:newId('A'),title:title,subtitle:subtitle,
      kind:kind,createdAt:DateTime.now()));
    if(db.activities.length>500) {
      db.activities.sort((a,b)=>b.createdAt.compareTo(a.createdAt));
      db.activities.removeRange(500,db.activities.length);
    }
  }

  Future<void> addProperty(PropertyModel p) => _mutate((db) {
    if (db.properties.any((e)=>e.propertyId==p.propertyId)) {
      throw StateError('Property ID already exists');
    }
    db.properties.insert(0,p);
    _activity(db,'Property added','${p.propertyId} • ${p.displayLocation}','property');
  });
  Future<void> updateProperty(PropertyModel p) => _mutate((db) {
    final i=db.properties.indexWhere((e)=>e.id==p.id);
    if(i<0) throw StateError('Property no longer exists');
    if(db.properties.any((e)=>e.id!=p.id && e.propertyId==p.propertyId)) {
      throw StateError('Another property already uses this property ID');
    }
    final previous=db.properties[i];
    final changes=<String>[];
    void changed(String label,Object? before,Object? after) {
      if('$before'!='$after') changes.add('$label: $before → $after');
    }
    changed('Property ID',previous.propertyId,p.propertyId);
    changed('Reference',previous.referenceNo,p.referenceNo);
    changed('Society',previous.society,p.society);
    changed('Block',previous.block,p.block);
    changed('Sector',previous.sector,p.sector);
    changed('Street',previous.street,p.street);
    changed('Plot',previous.plotNumber,p.plotNumber);
    changed('Type',previous.type,p.type);
    changed('Size','${previous.size} ${previous.unit}','${p.size} ${p.unit}');
    changed('Purpose',previous.purpose,p.purpose);
    changed('Status',previous.status,p.status);
    changed('Owner demand',previous.ownerDemand,p.ownerDemand);
    changed('Asking price',previous.askingPrice,p.askingPrice);
    changed('Expected deal price',previous.expectedDealPrice,p.expectedDealPrice);
    changed('Minimum price',previous.minimumPrice,p.minimumPrice);
    changed('Sale price',previous.salePrice,p.salePrice);
    changed('Commission',previous.commission,p.commission);
    changed('Token',previous.tokenAmount,p.tokenAmount);
    changed('Remaining',previous.remainingAmount,p.remainingAmount);
    changed('Payment terms',previous.paymentTerms,p.paymentTerms);
    changed('Owner name',previous.ownerName,p.ownerName);
    changed('Owner phone',previous.ownerPhone,p.ownerPhone);
    changed('Source',previous.source,p.source);
    changed('Source contact',previous.sourceContact,p.sourceContact);
    changed('Source detail',previous.sourceDetail,p.sourceDetail);
    if(previous.imagePaths.length!=p.imagePaths.length) changes.add('Photos: ${previous.imagePaths.length} → ${p.imagePaths.length}');
    if(previous.videoPaths.length!=p.videoPaths.length) changes.add('Videos: ${previous.videoPaths.length} → ${p.videoPaths.length}');
    if(previous.documentPaths.length!=p.documentPaths.length) changes.add('Documents: ${previous.documentPaths.length} → ${p.documentPaths.length}');
    final stamp=DateTime.now().toIso8601String();
    final history=[...previous.history];
    if(changes.isNotEmpty) history.add('$stamp | ${changes.join('; ')}');
    var normalized=p.copyWith(history:history);
    if(previous.status!='Sold' && p.status=='Sold') normalized=normalized.copyWith(soldAt:DateTime.now());
    if(previous.status=='Sold' && p.status!='Sold') normalized=normalized.copyWith(clearSoldAt:true);
    db.properties[i]=normalized;
    _activity(db,'Property updated','${p.propertyId} • ${p.status}','property');
  });
  Future<void> archiveProperty(String id) => _mutate((db) {
    final i=db.properties.indexWhere((e)=>e.id==id);
    if(i<0) throw StateError('Property not found');
    final old=db.properties[i];
    db.properties[i]=old.copyWith(status:'Archived',history:[...old.history,'${DateTime.now().toIso8601String()} | Archived']);
    _activity(db,'Property archived',db.properties[i].propertyId,'property');
  });
  Future<void> restoreArchivedProperty(String id) => _mutate((db) {
    final i=db.properties.indexWhere((e)=>e.id==id);
    if(i<0) throw StateError('Property not found');
    final old=db.properties[i];
    db.properties[i]=old.copyWith(status:'Available',history:[...old.history,'${DateTime.now().toIso8601String()} | Restored from archive']);
    _activity(db,'Property restored',old.propertyId,'property');
  });

  Future<void> addClient(ClientModel c) => _mutate((db) {
    db.clients.insert(0,c);
    _activity(db,'Client added',c.name,'client');
  });
  Future<void> replaceClient(ClientModel c) => _mutate((db) {
    final i=db.clients.indexWhere((e)=>e.id==c.id);
    if(i<0) throw StateError('Client not found');
    db.clients[i]=c;
    _activity(db,'Client updated',c.name,'client');
  });
  Future<void> addLead(LeadModel l) => _mutate((db) {
    db.leads.insert(0,l);
    _activity(db,'Lead added','${l.name} • ${l.source}','lead');
  });
  Future<void> updateLeadStage(String id,String stage) => _mutate((db) {
    final i=db.leads.indexWhere((e)=>e.id==id);
    if(i<0) throw StateError('Lead not found');
    db.leads[i]=db.leads[i].copyWith(stage:stage);
    _activity(db,'Lead stage changed','${db.leads[i].name} → $stage','lead');
  });
  Future<void> updateLeadTemperature(String id,String temperature) => _mutate((db) {
    final i=db.leads.indexWhere((e)=>e.id==id);
    if(i<0) throw StateError('Lead not found');
    db.leads[i]=db.leads[i].copyWith(temperature:temperature);
    _activity(db,'Lead score changed','${db.leads[i].name} → $temperature','lead');
  });
  Future<void> addFollowUp(FollowUpModel f) => _mutate((db) {
    db.followUps.insert(0,f);
    _activity(db,'Follow-up scheduled',f.contactName,'followup');
  });
  Future<void> setFollowUpCompleted(String id,bool done) => _mutate((db) {
    final i=db.followUps.indexWhere((e)=>e.id==id);
    if(i<0) throw StateError('Follow-up not found');
    db.followUps[i]=db.followUps[i].copyWith(status:done?'Completed':'Pending');
    _activity(db,done?'Follow-up completed':'Follow-up reopened',db.followUps[i].contactName,'followup');
  });
  Future<void> rescheduleFollowUp(String id,DateTime at) => _mutate((db) {
    final i=db.followUps.indexWhere((e)=>e.id==id);
    if(i<0) throw StateError('Follow-up not found');
    db.followUps[i]=db.followUps[i].copyWith(status:'Pending',scheduledAt:at);
    _activity(db,'Follow-up rescheduled',db.followUps[i].contactName,'followup');
  });

  Future<void> addSiteVisit(SiteVisitModel v) => _mutate((db) {
    if(!db.clients.any((c)=>c.id==v.clientId) || !db.properties.any((p)=>p.id==v.propertyId)) {
      throw StateError('Choose an existing client and property');
    }
    db.siteVisits.insert(0,v);
    _activity(db,'Site visit scheduled',v.scheduledAt.toString(),'visit');
  });
  Future<void> updateSiteVisit(SiteVisitModel v) => _mutate((db) {
    final i=db.siteVisits.indexWhere((e)=>e.id==v.id);
    if(i<0) throw StateError('Site visit not found');
    db.siteVisits[i]=v;
    if(v.status=='Completed' && ['Interested','Very Interested','Negotiating',
        'Needs More Options'].contains(v.outcome) &&
        !db.followUps.any((f)=>f.title=='Site visit feedback · ${v.id}')) {
      ClientModel? c;
      for(final item in db.clients){if(item.id==v.clientId){c=item;break;}}
      if(c!=null)db.followUps.add(FollowUpModel(
        id:newId('F'),followUpId:newId('FU'),clientId:c.id,
        leadId:'',propertyId:v.propertyId,
        title:'Site visit feedback · ${v.id}',contactName:c.name,
        phone:c.phone,scheduledAt:DateTime.now().add(const Duration(days:1)),
        type:'Call',status:'Pending',notes:'Client response: ${v.outcome}',
        createdAt:DateTime.now()));
    }
    _activity(db,'Site visit updated',v.status,'visit');
  });
  Future<void> addDeal(DealModel d) => _mutate((db) {
    if(!db.clients.any((c)=>c.id==d.buyerId) ||
       !db.properties.any((p)=>p.id==d.propertyId)) {
      throw StateError('Deal requires an existing buyer and property');
    }
    if(d.finalPrice<=0 || d.commissionRate<0 || d.commissionReceived<0 ||
       d.commissionReceived>d.commissionTotal || d.token>d.finalPrice) {
      throw StateError('Check deal price, token and commission amounts');
    }
    db.deals.insert(0,d);
    _syncDealProperty(db,d);
    _activity(db,'Deal created',d.id,'deal');
  });
  Future<void> updateDeal(DealModel d) => _mutate((db) {
    final i=db.deals.indexWhere((e)=>e.id==d.id);
    if(i<0) throw StateError('Deal not found');
    if(d.commissionReceived<0 || d.commissionReceived>d.commissionTotal) {
      throw StateError('Received commission exceeds total');
    }
    db.deals[i]=d;
    _syncDealProperty(db,d);
    _activity(db,'Deal updated','${d.id} • ${d.status}','deal');
  });
  void _syncDealProperty(EstatePilotDatabase db,DealModel deal) {
    final index=db.properties.indexWhere((p)=>p.id==deal.propertyId);
    if(index<0)return;
    final status=deal.status=='Completed'?'Sold':
      ['Token Received','Documentation','Transfer'].contains(deal.status)?'Reserved':null;
    if(status!=null && db.properties[index].status!=status) {
      final old=db.properties[index];
      final history=[...old.history,'${DateTime.now().toIso8601String()} | Deal status changed property → $status'];
      db.properties[index]=old.copyWith(
        status:status,
        salePrice:status=='Sold' && deal.finalPrice>0 ? deal.finalPrice : old.salePrice,
        tokenAmount:deal.token,
        remainingAmount:deal.remainingAmount,
        commission:deal.commissionTotal,
        soldAt:status=='Sold'?DateTime.now():null,
        history:history,
      );
      _activity(db,'Property status updated from deal',
        '${db.properties[index].propertyId} → $status','property');
    }
  }

  Future<void> upsertSociety(SocietyModel s) => _mutate((db) {
    final i=db.societies.indexWhere((e)=>e.id==s.id);
    if(i<0) {db.societies.add(s);} else {db.societies[i]=s;}
    _activity(db,'Society updated',s.name,'society');
  });
  Future<void> addMarketRate(MarketRateModel r) => _mutate((db) {
    db.marketRates.insert(0,r);
    _activity(db,'Market rate recorded','${r.society} • ${r.block}','market');
  });
  Future<void> upsertVerification(VerificationModel v) => _mutate((db) {
    final i=db.verifications.indexWhere((e)=>e.propertyId==v.propertyId);
    if(i<0) {db.verifications.add(v);} else {db.verifications[i]=v;}
    _activity(db,'Property verification updated',v.propertyId,'verification');
  });

  Future<void> updateSettings(AppSettingsModel value) => _mutate((db) {
    if(db.appSettings.isEmpty) {db.appSettings.add(value);} else {db.appSettings[0]=value;}
    _activity(db,'Settings updated','EstatePilot preferences saved','settings');
  });

  Future<void> markPropertySold(String propertyId,{double? salePrice}) => _mutate((db) {
    final i=db.properties.indexWhere((p)=>p.id==propertyId);
    if(i<0) throw StateError('Property not found');
    final old=db.properties[i];
    db.properties[i]=old.copyWith(status:'Sold',salePrice:salePrice??old.salePrice,
      soldAt:DateTime.now(),history:[...old.history,'${DateTime.now().toIso8601String()} | Marked SOLD']);
    _activity(db,'Property sold',old.propertyId,'property');
  });

  /// Export is user-initiated; private CRM data is not sent to a remote server.
  Future<bool> exportBackup() async => _store.exportBackup(_db);
  Future<bool> restoreBackup() async {
    final imported=await _store.importBackup();
    if(imported==null) return false;
    final operation=Completer<void>();
    _pending=_pending.then((_) async {
      if(_loadFailure!=null) throw StateError(_loadFailure!);
      await _store.save(imported);
      _db=imported;
      _lastError=null;
      notifyListeners();
    }).then((_)=>operation.complete()).catchError((Object e,StackTrace s) {
      _lastError='Restore failed; original data retained: $e';
      notifyListeners();
      operation.completeError(e,s);
    });
    await operation.future;
    return true;
  }

  List<PropertyModel> searchProperties(String query) {
    final q=query.trim().toLowerCase();
    return _db.properties.where((p) {
      return [p.propertyId,p.referenceNo,p.society,p.block,p.sector,p.street,p.plotNumber,
        p.type,p.size,p.ownerName,p.ownerPhone,p.source,p.sourceContact,p.sourceDetail,p.status]
        .join(' ').toLowerCase().contains(q);
    }).toList();
  }
  List<ClientModel> searchClients(String query) {
    final q=query.trim().toLowerCase();
    return _db.clients.where((c)=>[c.clientId,c.name,c.phone,c.whatsapp,c.email,
      c.city,...c.roles,c.preferredSociety,c.status].join(' ').toLowerCase().contains(q)).toList();
  }
  List<LeadModel> searchLeads(String query) {
    final q=query.trim().toLowerCase();
    return _db.leads.where((l)=>[l.leadId,l.name,l.phone,l.source,
      l.stage,l.temperature,l.requirement].join(' ').toLowerCase().contains(q)).toList();
  }
  PropertyModel? propertyById(String id) {
    for(final p in _db.properties) {if(p.id==id) return p;}
    return null;
  }
  ClientModel? clientById(String id) {
    for(final c in _db.clients) {if(c.id==id) return c;}
    return null;
  }
  VerificationModel? verificationByProperty(String id) {
    for(final v in _db.verifications) {if(v.propertyId==id) return v;}
    return null;
  }

  List<PropertyMatch> matchesFor(ClientModel buyer) {
    final list=<PropertyMatch>[];
    for(final p in _db.properties) {
      if(!['Available','Hold'].contains(p.status)) continue;
      var total=0;
      var earned=0;
      final reasons=<String>[];
      void assess(int weight,bool matches,String pass,String fail) {
        total+=weight;
        if(matches) {earned+=weight;reasons.add('✓ $pass');}
        else {reasons.add('• $fail');}
      }
      if(buyer.preferredSociety.isNotEmpty) assess(25,
        p.society.toLowerCase().contains(buyer.preferredSociety.toLowerCase()) ||
        buyer.preferredSociety.toLowerCase().contains(p.society.toLowerCase()),
        'Society matched','Different society');
      if(buyer.preferredPropertyType.isNotEmpty) assess(15,
        p.type.toLowerCase()==buyer.preferredPropertyType.toLowerCase(),
        'Property type matched','Different property type');
      if(buyer.preferredSize.isNotEmpty) {
        final wanted=buyer.preferredSize.toLowerCase().replaceAll(' ','');
        final basic=p.size.toLowerCase().replaceAll(' ','');
        final withUnit='${p.size}${p.unit}'.toLowerCase().replaceAll(' ','');
        assess(15,wanted==basic || wanted==withUnit,
          'Size matched','Different size');
      }
      if(buyer.budgetMin>0 || buyer.budgetMax>0) assess(25,
        p.displayPrice>0 && p.displayPrice>=buyer.budgetMin &&
        (buyer.budgetMax<=0 || p.displayPrice<=buyer.budgetMax),
        'Within buyer budget','Outside buyer budget');
      if(buyer.purpose.isNotEmpty) assess(5,
        p.purpose.toLowerCase()==buyer.purpose.toLowerCase() ||
        (buyer.purpose=='Investment' && p.purpose=='Sale'),
        'Purpose compatible','Purpose may differ');
      for(final preference in buyer.preferences) {
        final key=preference.toLowerCase().trim();
        bool? yes;
        if(key.contains('corner')) yes=p.corner;
        if(key.contains('park')) yes=p.parkFacing;
        if(key.contains('main road') || key.contains('boulevard')) yes=p.mainRoad;
        if(key.contains('possession')) yes=p.possession;
        if(yes!=null) assess(5,yes,'$preference matched','$preference not available');
      }
      if(total==0) {total=1;earned=0;reasons.add('Add buyer requirements to calculate a match');}
      list.add(PropertyMatch(p,(100*earned/total).round().clamp(0,100).toInt(),reasons));
    }
    list.sort((a,b)=>b.score.compareTo(a.score));
    return list;
  }
}

class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({super.key,required AppState notifier,required super.child})
      : super(notifier:notifier);
  static AppState of(BuildContext context) {
    final scope=context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    assert(scope!=null,'AppStateScope is missing');
    return scope!.notifier!;
  }
}
