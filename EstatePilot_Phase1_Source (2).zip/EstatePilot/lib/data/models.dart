import 'dart:math';

String newId(String prefix) {
  final now = DateTime.now().microsecondsSinceEpoch;
  final salt = Random().nextInt(9999).toString().padLeft(4, '0');
  return '$prefix-$now-$salt';
}

DateTime _date(dynamic value) {
  if (value is String) return DateTime.tryParse(value) ?? DateTime.now();
  return DateTime.now();
}

double _number(dynamic value) {
  if (value is num) return value.toDouble();
  return double.tryParse('$value') ?? 0;
}

bool _bool(dynamic value) => value == true || value == 1 || value == 'true';

class PropertyModel {
  const PropertyModel({
    required this.id,
    required this.propertyId,
    required this.referenceNo,
    required this.society,
    required this.block,
    required this.sector,
    required this.street,
    required this.plotNumber,
    required this.type,
    required this.size,
    required this.unit,
    required this.purpose,
    required this.status,
    required this.ownerDemand,
    required this.askingPrice,
    required this.expectedDealPrice,
    required this.minimumPrice,
    required this.salePrice,
    required this.commission,
    required this.tokenAmount,
    required this.remainingAmount,
    required this.paymentTerms,
    required this.installmentAvailable,
    required this.ownerName,
    required this.ownerPhone,
    required this.source,
    required this.sourceContact,
    required this.sourceDetail,
    required this.roadWidth,
    required this.facing,
    required this.locationNotes,
    required this.notes,
    required this.corner,
    required this.parkFacing,
    required this.mainRoad,
    required this.possession,
    required this.electricity,
    required this.gas,
    required this.water,
    required this.sewerage,
    required this.negotiable,
    required this.urgentSale,
    required this.imagePaths,
    required this.videoPaths,
    required this.documentPaths,
    required this.history,
    required this.soldAt,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String propertyId;
  final String referenceNo;
  final String society;
  final String block;
  final String sector;
  final String street;
  final String plotNumber;
  final String type;
  final String size;
  final String unit;
  final String purpose;
  final String status;
  final double ownerDemand;
  final double askingPrice;
  final double expectedDealPrice;
  final double minimumPrice;
  final double salePrice;
  final double commission;
  final double tokenAmount;
  final double remainingAmount;
  final String paymentTerms;
  final bool installmentAvailable;
  final String ownerName;
  final String ownerPhone;
  final String source;
  final String sourceContact;
  final String sourceDetail;
  final String roadWidth;
  final String facing;
  final String locationNotes;
  final String notes;
  final bool corner;
  final bool parkFacing;
  final bool mainRoad;
  final bool possession;
  final bool electricity;
  final bool gas;
  final bool water;
  final bool sewerage;
  final bool negotiable;
  final bool urgentSale;
  final List<String> imagePaths;
  final List<String> videoPaths;
  final List<String> documentPaths;
  final List<String> history;
  final DateTime? soldAt;
  final DateTime createdAt;
  final DateTime updatedAt;

  String get displayLocation {
    final parts = [society, block, sector, street,
      plotNumber.isEmpty ? '' : 'Plot $plotNumber']
        .where((e) => e.trim().isNotEmpty).toList();
    return parts.join(' • ');
  }

  double get displayPrice {
    if (status == 'Sold' && salePrice > 0) return salePrice;
    if (expectedDealPrice > 0) return expectedDealPrice;
    if (askingPrice > 0) return askingPrice;
    return ownerDemand;
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'propertyId': propertyId,
    'referenceNo': referenceNo,
    'society': society,
    'block': block,
    'sector': sector,
    'street': street,
    'plotNumber': plotNumber,
    'type': type,
    'size': size,
    'unit': unit,
    'purpose': purpose,
    'status': status,
    'ownerDemand': ownerDemand,
    'askingPrice': askingPrice,
    'expectedDealPrice': expectedDealPrice,
    'minimumPrice': minimumPrice,
    'salePrice': salePrice,
    'commission': commission,
    'tokenAmount': tokenAmount,
    'remainingAmount': remainingAmount,
    'paymentTerms': paymentTerms,
    'installmentAvailable': installmentAvailable,
    'ownerName': ownerName,
    'ownerPhone': ownerPhone,
    'source': source,
    'sourceContact': sourceContact,
    'sourceDetail': sourceDetail,
    'roadWidth': roadWidth,
    'facing': facing,
    'locationNotes': locationNotes,
    'notes': notes,
    'corner': corner,
    'parkFacing': parkFacing,
    'mainRoad': mainRoad,
    'possession': possession,
    'electricity': electricity,
    'gas': gas,
    'water': water,
    'sewerage': sewerage,
    'negotiable': negotiable,
    'urgentSale': urgentSale,
    'imagePaths': imagePaths,
    'videoPaths': videoPaths,
    'documentPaths': documentPaths,
    'history': history,
    'soldAt': soldAt?.toIso8601String(),
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
  };

  factory PropertyModel.fromJson(Map<String, dynamic> json) => PropertyModel(
    id: '${json['id'] ?? newId('P')}',
    propertyId: '${json['propertyId'] ?? ''}',
    referenceNo: '${json['referenceNo'] ?? json['propertyId'] ?? ''}',
    society: '${json['society'] ?? ''}',
    block: '${json['block'] ?? ''}',
    sector: '${json['sector'] ?? ''}',
    street: '${json['street'] ?? ''}',
    plotNumber: '${json['plotNumber'] ?? ''}',
    type: '${json['type'] ?? 'Residential Plot'}',
    size: '${json['size'] ?? ''}',
    unit: '${json['unit'] ?? 'Marla'}',
    purpose: '${json['purpose'] ?? 'Sale'}',
    status: '${json['status'] ?? 'Available'}',
    ownerDemand: _number(json['ownerDemand']),
    askingPrice: _number(json['askingPrice'] ?? json['ownerDemand']),
    expectedDealPrice: _number(json['expectedDealPrice']),
    minimumPrice: _number(json['minimumPrice']),
    salePrice: _number(json['salePrice']),
    commission: _number(json['commission']),
    tokenAmount: _number(json['tokenAmount']),
    remainingAmount: _number(json['remainingAmount']),
    paymentTerms: '${json['paymentTerms'] ?? ''}',
    installmentAvailable: _bool(json['installmentAvailable']),
    ownerName: '${json['ownerName'] ?? ''}',
    ownerPhone: '${json['ownerPhone'] ?? ''}',
    source: '${json['source'] ?? 'Owner Direct'}',
    sourceContact: '${json['sourceContact'] ?? ''}',
    sourceDetail: '${json['sourceDetail'] ?? ''}',
    roadWidth: '${json['roadWidth'] ?? ''}',
    facing: '${json['facing'] ?? ''}',
    locationNotes: '${json['locationNotes'] ?? ''}',
    notes: '${json['notes'] ?? ''}',
    corner: _bool(json['corner']),
    parkFacing: _bool(json['parkFacing']),
    mainRoad: _bool(json['mainRoad']),
    possession: _bool(json['possession']),
    electricity: _bool(json['electricity']),
    gas: _bool(json['gas']),
    water: _bool(json['water']),
    sewerage: _bool(json['sewerage']),
    negotiable: _bool(json['negotiable']),
    urgentSale: _bool(json['urgentSale']),
    imagePaths: (json['imagePaths'] as List? ?? const []).map((e) => '$e').toList(),
    videoPaths: (json['videoPaths'] as List? ?? const []).map((e) => '$e').toList(),
    documentPaths: (json['documentPaths'] as List? ?? const []).map((e) => '$e').toList(),
    history: (json['history'] as List? ?? const []).map((e) => '$e').toList(),
    soldAt: json['soldAt'] == null || '${json['soldAt']}'.isEmpty ? null : _date(json['soldAt']),
    createdAt: _date(json['createdAt']),
    updatedAt: _date(json['updatedAt']),
  );

  PropertyModel copyWith({
    String? propertyId,
    String? referenceNo,
    String? society,
    String? block,
    String? sector,
    String? street,
    String? plotNumber,
    String? type,
    String? size,
    String? unit,
    String? purpose,
    String? status,
    double? ownerDemand,
    double? askingPrice,
    double? expectedDealPrice,
    double? minimumPrice,
    double? salePrice,
    double? commission,
    double? tokenAmount,
    double? remainingAmount,
    String? paymentTerms,
    bool? installmentAvailable,
    String? ownerName,
    String? ownerPhone,
    String? source,
    String? sourceContact,
    String? sourceDetail,
    String? roadWidth,
    String? facing,
    String? locationNotes,
    String? notes,
    bool? corner,
    bool? parkFacing,
    bool? mainRoad,
    bool? possession,
    bool? electricity,
    bool? gas,
    bool? water,
    bool? sewerage,
    bool? negotiable,
    bool? urgentSale,
    List<String>? imagePaths,
    List<String>? videoPaths,
    List<String>? documentPaths,
    List<String>? history,
    DateTime? soldAt,
    bool clearSoldAt = false,
  }) => PropertyModel(
    id: id,
    propertyId: propertyId ?? this.propertyId,
    referenceNo: referenceNo ?? this.referenceNo,
    society: society ?? this.society,
    block: block ?? this.block,
    sector: sector ?? this.sector,
    street: street ?? this.street,
    plotNumber: plotNumber ?? this.plotNumber,
    type: type ?? this.type,
    size: size ?? this.size,
    unit: unit ?? this.unit,
    purpose: purpose ?? this.purpose,
    status: status ?? this.status,
    ownerDemand: ownerDemand ?? this.ownerDemand,
    askingPrice: askingPrice ?? this.askingPrice,
    expectedDealPrice: expectedDealPrice ?? this.expectedDealPrice,
    minimumPrice: minimumPrice ?? this.minimumPrice,
    salePrice: salePrice ?? this.salePrice,
    commission: commission ?? this.commission,
    tokenAmount: tokenAmount ?? this.tokenAmount,
    remainingAmount: remainingAmount ?? this.remainingAmount,
    paymentTerms: paymentTerms ?? this.paymentTerms,
    installmentAvailable: installmentAvailable ?? this.installmentAvailable,
    ownerName: ownerName ?? this.ownerName,
    ownerPhone: ownerPhone ?? this.ownerPhone,
    source: source ?? this.source,
    sourceContact: sourceContact ?? this.sourceContact,
    sourceDetail: sourceDetail ?? this.sourceDetail,
    roadWidth: roadWidth ?? this.roadWidth,
    facing: facing ?? this.facing,
    locationNotes: locationNotes ?? this.locationNotes,
    notes: notes ?? this.notes,
    corner: corner ?? this.corner,
    parkFacing: parkFacing ?? this.parkFacing,
    mainRoad: mainRoad ?? this.mainRoad,
    possession: possession ?? this.possession,
    electricity: electricity ?? this.electricity,
    gas: gas ?? this.gas,
    water: water ?? this.water,
    sewerage: sewerage ?? this.sewerage,
    negotiable: negotiable ?? this.negotiable,
    urgentSale: urgentSale ?? this.urgentSale,
    imagePaths: imagePaths ?? this.imagePaths,
    videoPaths: videoPaths ?? this.videoPaths,
    documentPaths: documentPaths ?? this.documentPaths,
    history: history ?? this.history,
    soldAt: clearSoldAt ? null : (soldAt ?? this.soldAt),
    createdAt: createdAt,
    updatedAt: DateTime.now(),
  );
}

class ClientModel {
  const ClientModel({
    required this.id,
    required this.clientId,
    required this.name,
    required this.phone,
    required this.whatsapp,
    required this.email,
    required this.city,
    required this.roles,
    required this.budgetMin,
    required this.budgetMax,
    required this.preferredSociety,
    required this.preferredPropertyType,
    required this.preferredSize,
    required this.purpose,
    required this.timeline,
    required this.preferences,
    required this.source,
    required this.status,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String clientId;
  final String name;
  final String phone;
  final String whatsapp;
  final String email;
  final String city;
  final List<String> roles;
  final double budgetMin;
  final double budgetMax;
  final String preferredSociety;
  final String preferredPropertyType;
  final String preferredSize;
  final String purpose;
  final String timeline;
  final List<String> preferences;
  final String source;
  final String status;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'clientId': clientId,
        'name': name,
        'phone': phone,
        'whatsapp': whatsapp,
        'email': email,
        'city': city,
        'roles': roles,
        'budgetMin': budgetMin,
        'budgetMax': budgetMax,
        'preferredSociety': preferredSociety,
        'preferredPropertyType': preferredPropertyType,
        'preferredSize': preferredSize,
        'purpose': purpose,
        'timeline': timeline,
        'preferences': preferences,
        'source': source,
        'status': status,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory ClientModel.fromJson(Map<String, dynamic> json) => ClientModel(
        id: '${json['id'] ?? newId('C')}',
        clientId: '${json['clientId'] ?? ''}',
        name: '${json['name'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        whatsapp: '${json['whatsapp'] ?? ''}',
        email: '${json['email'] ?? ''}',
        city: '${json['city'] ?? ''}',
        roles: (json['roles'] as List? ?? const ['Buyer']).map((e) => '$e').toList(),
        budgetMin: _number(json['budgetMin']),
        budgetMax: _number(json['budgetMax']),
        preferredSociety: '${json['preferredSociety'] ?? ''}',
        preferredPropertyType: '${json['preferredPropertyType'] ?? ''}',
        preferredSize: '${json['preferredSize'] ?? ''}',
        purpose: '${json['purpose'] ?? ''}',
        timeline: '${json['timeline'] ?? 'Flexible'}',
        preferences: (json['preferences'] as List? ?? const []).map((e) => '$e').toList(),
        source: '${json['source'] ?? 'Referral'}',
        status: '${json['status'] ?? 'Active'}',
        notes: '${json['notes'] ?? ''}',
        createdAt: _date(json['createdAt']),
        updatedAt: _date(json['updatedAt']),
      );
}

class LeadModel {
  const LeadModel({
    required this.id,
    required this.leadId,
    required this.clientId,
    required this.name,
    required this.phone,
    required this.source,
    required this.stage,
    required this.temperature,
    required this.requirement,
    required this.assignedTo,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String leadId;
  final String clientId;
  final String name;
  final String phone;
  final String source;
  final String stage;
  final String temperature;
  final String requirement;
  final String assignedTo;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'leadId': leadId,
        'clientId': clientId,
        'name': name,
        'phone': phone,
        'source': source,
        'stage': stage,
        'temperature': temperature,
        'requirement': requirement,
        'assignedTo': assignedTo,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory LeadModel.fromJson(Map<String, dynamic> json) => LeadModel(
        id: '${json['id'] ?? newId('L')}',
        leadId: '${json['leadId'] ?? ''}',
        clientId: '${json['clientId'] ?? ''}',
        name: '${json['name'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        source: '${json['source'] ?? 'WhatsApp'}',
        stage: '${json['stage'] ?? 'New'}',
        temperature: '${json['temperature'] ?? 'Warm'}',
        requirement: '${json['requirement'] ?? ''}',
        assignedTo: '${json['assignedTo'] ?? 'Me'}',
        notes: '${json['notes'] ?? ''}',
        createdAt: _date(json['createdAt']),
        updatedAt: _date(json['updatedAt']),
      );

  LeadModel copyWith({String? stage, String? temperature}) => LeadModel(
        id: id,
        leadId: leadId,
        clientId: clientId,
        name: name,
        phone: phone,
        source: source,
        stage: stage ?? this.stage,
        temperature: temperature ?? this.temperature,
        requirement: requirement,
        assignedTo: assignedTo,
        notes: notes,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );
}

class FollowUpModel {
  const FollowUpModel({
    required this.id,
    required this.followUpId,
    required this.clientId,
    required this.leadId,
    required this.propertyId,
    required this.title,
    required this.contactName,
    required this.phone,
    required this.scheduledAt,
    required this.type,
    required this.status,
    required this.notes,
    required this.createdAt,
  });

  final String id;
  final String followUpId;
  final String clientId;
  final String leadId;
  final String propertyId;
  final String title;
  final String contactName;
  final String phone;
  final DateTime scheduledAt;
  final String type;
  final String status;
  final String notes;
  final DateTime createdAt;

  bool get isCompleted => status == 'Completed';

  Map<String, dynamic> toJson() => {
        'id': id,
        'followUpId': followUpId,
        'clientId': clientId,
        'leadId': leadId,
        'propertyId': propertyId,
        'title': title,
        'contactName': contactName,
        'phone': phone,
        'scheduledAt': scheduledAt.toIso8601String(),
        'type': type,
        'status': status,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
      };

  factory FollowUpModel.fromJson(Map<String, dynamic> json) => FollowUpModel(
        id: '${json['id'] ?? newId('F')}',
        followUpId: '${json['followUpId'] ?? ''}',
        clientId: '${json['clientId'] ?? ''}',
        leadId: '${json['leadId'] ?? ''}',
        propertyId: '${json['propertyId'] ?? ''}',
        title: '${json['title'] ?? 'Follow-up'}',
        contactName: '${json['contactName'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        scheduledAt: _date(json['scheduledAt']),
        type: '${json['type'] ?? 'Call'}',
        status: '${json['status'] ?? 'Pending'}',
        notes: '${json['notes'] ?? ''}',
        createdAt: _date(json['createdAt']),
      );

  FollowUpModel copyWith({String? status, DateTime? scheduledAt}) => FollowUpModel(
        id: id,
        followUpId: followUpId,
        clientId: clientId,
        leadId: leadId,
        propertyId: propertyId,
        title: title,
        contactName: contactName,
        phone: phone,
        scheduledAt: scheduledAt ?? this.scheduledAt,
        type: type,
        status: status ?? this.status,
        notes: notes,
        createdAt: createdAt,
      );
}

class ActivityModel {
  const ActivityModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.kind,
    required this.createdAt,
  });

  final String id;
  final String title;
  final String subtitle;
  final String kind;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'kind': kind,
        'createdAt': createdAt.toIso8601String(),
      };

  factory ActivityModel.fromJson(Map<String, dynamic> json) => ActivityModel(
        id: '${json['id'] ?? newId('A')}',
        title: '${json['title'] ?? ''}',
        subtitle: '${json['subtitle'] ?? ''}',
        kind: '${json['kind'] ?? 'general'}',
        createdAt: _date(json['createdAt']),
      );
}

class SiteVisitModel {
  const SiteVisitModel({required this.id, required this.clientId, required this.propertyId,
    required this.scheduledAt, required this.status, required this.outcome,
    required this.notes, required this.assignedTo, required this.createdAt});
  final String id, clientId, propertyId, status, outcome, notes, assignedTo;
  final DateTime scheduledAt, createdAt;
  Map<String,dynamic> toJson() => {
    'id': id, 'clientId': clientId, 'propertyId': propertyId,
    'scheduledAt': scheduledAt.toIso8601String(), 'status': status,
    'outcome': outcome, 'notes': notes, 'assignedTo': assignedTo,
    'createdAt': createdAt.toIso8601String()};
  factory SiteVisitModel.fromJson(Map<String,dynamic> j) => SiteVisitModel(
    id: '${j['id'] ?? newId('V')}', clientId: '${j['clientId'] ?? ''}',
    propertyId: '${j['propertyId'] ?? ''}', scheduledAt: _date(j['scheduledAt']),
    status: '${j['status'] ?? 'Scheduled'}', outcome: '${j['outcome'] ?? ''}',
    notes: '${j['notes'] ?? ''}', assignedTo: '${j['assignedTo'] ?? ''}',
    createdAt: _date(j['createdAt']));
  SiteVisitModel copyWith({String? status, String? outcome, String? notes,
    DateTime? scheduledAt}) => SiteVisitModel(id: id, clientId: clientId,
    propertyId: propertyId, scheduledAt: scheduledAt ?? this.scheduledAt,
    status: status ?? this.status, outcome: outcome ?? this.outcome,
    notes: notes ?? this.notes, assignedTo: assignedTo, createdAt: createdAt);
}

class DealModel {
  const DealModel({required this.id, required this.buyerId, required this.sellerId,
    required this.propertyId, required this.finalPrice, required this.token,
    required this.commissionRate, required this.commissionReceived,
    required this.status, required this.notes, required this.dealDate});
  final String id, buyerId, sellerId, propertyId, status, notes;
  final double finalPrice, token, commissionRate, commissionReceived;
  final DateTime dealDate;
  double get commissionTotal => finalPrice * commissionRate / 100;
  double get commissionPending => (commissionTotal - commissionReceived).clamp(0, double.infinity).toDouble();
  double get remainingAmount => (finalPrice - token).clamp(0, double.infinity).toDouble();
  Map<String,dynamic> toJson() => {'id': id, 'buyerId': buyerId,
    'sellerId': sellerId, 'propertyId': propertyId, 'finalPrice': finalPrice,
    'token': token, 'commissionRate': commissionRate,
    'commissionReceived': commissionReceived, 'status': status,
    'notes': notes, 'dealDate': dealDate.toIso8601String()};
  factory DealModel.fromJson(Map<String,dynamic> j) => DealModel(
    id: '${j['id'] ?? newId('D')}', buyerId: '${j['buyerId'] ?? ''}',
    sellerId: '${j['sellerId'] ?? ''}', propertyId: '${j['propertyId'] ?? ''}',
    finalPrice: _number(j['finalPrice']), token: _number(j['token']),
    commissionRate: _number(j['commissionRate']),
    commissionReceived: _number(j['commissionReceived']),
    status: '${j['status'] ?? 'Negotiation'}', notes: '${j['notes'] ?? ''}',
    dealDate: _date(j['dealDate']));
  DealModel copyWith({String? status, double? commissionReceived,
    double? token}) => DealModel(id: id, buyerId: buyerId,
    sellerId: sellerId, propertyId: propertyId, finalPrice: finalPrice,
    token: token ?? this.token, commissionRate: commissionRate,
    commissionReceived: commissionReceived ?? this.commissionReceived,
    status: status ?? this.status, notes: notes, dealDate: dealDate);
}

class SocietyModel {
  const SocietyModel({required this.id, required this.name, required this.location,
    required this.blocks, required this.notes});
  final String id, name, location, notes;
  final List<String> blocks;
  Map<String,dynamic> toJson() => {'id': id,'name':name,'location':location,
    'blocks':blocks,'notes':notes};
  factory SocietyModel.fromJson(Map<String,dynamic> j) => SocietyModel(
    id: '${j['id'] ?? newId('S')}',name:'${j['name'] ?? ''}',
    location:'${j['location'] ?? ''}',
    blocks:(j['blocks'] as List? ?? const []).map((e)=>'$e').toList(),
    notes:'${j['notes'] ?? ''}');
  SocietyModel copyWith({String? name,String? location,List<String>? blocks,String? notes}) =>
    SocietyModel(id:id,name:name??this.name,location:location??this.location,
      blocks:blocks??this.blocks,notes:notes??this.notes);
}

class MarketRateModel {
  const MarketRateModel({required this.id, required this.society, required this.block,
    required this.size, required this.propertyType, required this.askingRate,
    required this.dealRate, required this.recordedAt, required this.source,
    required this.notes});
  final String id,society,block,size,propertyType,source,notes;
  final double askingRate,dealRate;
  final DateTime recordedAt;
  Map<String,dynamic> toJson() => {'id':id,'society':society,'block':block,
    'size':size,'propertyType':propertyType,'askingRate':askingRate,
    'dealRate':dealRate,'recordedAt':recordedAt.toIso8601String(),
    'source':source,'notes':notes};
  factory MarketRateModel.fromJson(Map<String,dynamic> j) => MarketRateModel(
    id:'${j['id'] ?? newId('R')}',society:'${j['society'] ?? ''}',
    block:'${j['block'] ?? ''}',size:'${j['size'] ?? ''}',
    propertyType:'${j['propertyType'] ?? ''}',
    askingRate:_number(j['askingRate']),dealRate:_number(j['dealRate']),
    recordedAt:_date(j['recordedAt']),source:'${j['source'] ?? ''}',
    notes:'${j['notes'] ?? ''}');
}

class VerificationModel {
  const VerificationModel({required this.id, required this.propertyId,
    required this.checks, required this.notes, required this.checkedAt});
  final String id,propertyId,notes;
  final Map<String,bool> checks;
  final DateTime checkedAt;
  int get checkedCount => checks.values.where((v)=>v).length;
  Map<String,dynamic> toJson() => {'id':id,'propertyId':propertyId,
    'checks':checks,'notes':notes,'checkedAt':checkedAt.toIso8601String()};
  factory VerificationModel.fromJson(Map<String,dynamic> j) => VerificationModel(
    id:'${j['id'] ?? newId('VR')}',propertyId:'${j['propertyId'] ?? ''}',
    checks:(j['checks'] is Map ? Map<String,dynamic>.from(j['checks'] as Map) : <String,dynamic>{})
      .map((k,v)=>MapEntry(k,_bool(v))),
    notes:'${j['notes'] ?? ''}',checkedAt:_date(j['checkedAt']));
}

class AppSettingsModel {
  const AppSettingsModel({
    required this.id,
    required this.profileName,
    required this.profilePhone,
    required this.currency,
    required this.dateFormat,
    required this.defaultSociety,
    required this.defaultPropertyView,
    required this.themeMode,
  });

  final String id;
  final String profileName;
  final String profilePhone;
  final String currency;
  final String dateFormat;
  final String defaultSociety;
  final String defaultPropertyView;
  final String themeMode;

  Map<String,dynamic> toJson()=>{
    'id':id,'profileName':profileName,'profilePhone':profilePhone,
    'currency':currency,'dateFormat':dateFormat,'defaultSociety':defaultSociety,
    'defaultPropertyView':defaultPropertyView,'themeMode':themeMode,
  };

  factory AppSettingsModel.fromJson(Map<String,dynamic> j)=>AppSettingsModel(
    id:'${j['id']??'APP-SETTINGS'}',
    profileName:'${j['profileName']??''}',
    profilePhone:'${j['profilePhone']??''}',
    currency:'${j['currency']??'PKR'}',
    dateFormat:'${j['dateFormat']??'dd MMM yyyy'}',
    defaultSociety:'${j['defaultSociety']??'B-17'}',
    defaultPropertyView:'${j['defaultPropertyView']??'Active'}',
    themeMode:'${j['themeMode']??'dark'}',
  );

  AppSettingsModel copyWith({String? profileName,String? profilePhone,
    String? currency,String? dateFormat,String? defaultSociety,
    String? defaultPropertyView,String? themeMode})=>AppSettingsModel(
      id:id,profileName:profileName??this.profileName,
      profilePhone:profilePhone??this.profilePhone,currency:currency??this.currency,
      dateFormat:dateFormat??this.dateFormat,defaultSociety:defaultSociety??this.defaultSociety,
      defaultPropertyView:defaultPropertyView??this.defaultPropertyView,
      themeMode:themeMode??this.themeMode);
}

class EstatePilotDatabase {
  EstatePilotDatabase({
    List<PropertyModel>? properties,
    List<ClientModel>? clients,
    List<LeadModel>? leads,
    List<FollowUpModel>? followUps,
    List<ActivityModel>? activities,
    List<SiteVisitModel>? siteVisits,
    List<DealModel>? deals,
    List<SocietyModel>? societies,
    List<MarketRateModel>? marketRates,
    List<VerificationModel>? verifications,
    List<AppSettingsModel>? appSettings,
  }) : properties=properties ?? <PropertyModel>[],
       clients=clients ?? <ClientModel>[],
       leads=leads ?? <LeadModel>[],
       followUps=followUps ?? <FollowUpModel>[],
       activities=activities ?? <ActivityModel>[],
       siteVisits=siteVisits ?? <SiteVisitModel>[],
       deals=deals ?? <DealModel>[],
       societies=societies ?? <SocietyModel>[],
       marketRates=marketRates ?? <MarketRateModel>[],
       verifications=verifications ?? <VerificationModel>[],
       appSettings=appSettings ?? <AppSettingsModel>[];

  final List<PropertyModel> properties;
  final List<ClientModel> clients;
  final List<LeadModel> leads;
  final List<FollowUpModel> followUps;
  final List<ActivityModel> activities;
  final List<SiteVisitModel> siteVisits;
  final List<DealModel> deals;
  final List<SocietyModel> societies;
  final List<MarketRateModel> marketRates;
  final List<VerificationModel> verifications;
  final List<AppSettingsModel> appSettings;

  bool get hasBusinessData => properties.isNotEmpty || clients.isNotEmpty ||
    leads.isNotEmpty || followUps.isNotEmpty || activities.isNotEmpty ||
    siteVisits.isNotEmpty || deals.isNotEmpty || societies.isNotEmpty ||
    marketRates.isNotEmpty || verifications.isNotEmpty;

  Map<String,dynamic> toJson() => {
    'schemaVersion':3,
    'properties':properties.map((e)=>e.toJson()).toList(),
    'clients':clients.map((e)=>e.toJson()).toList(),
    'leads':leads.map((e)=>e.toJson()).toList(),
    'followUps':followUps.map((e)=>e.toJson()).toList(),
    'activities':activities.map((e)=>e.toJson()).toList(),
    'siteVisits':siteVisits.map((e)=>e.toJson()).toList(),
    'deals':deals.map((e)=>e.toJson()).toList(),
    'societies':societies.map((e)=>e.toJson()).toList(),
    'marketRates':marketRates.map((e)=>e.toJson()).toList(),
    'verifications':verifications.map((e)=>e.toJson()).toList(),
    'appSettings':appSettings.map((e)=>e.toJson()).toList(),
  };

  factory EstatePilotDatabase.fromJson(Map<String,dynamic> json) {
    List<T> parse<T>(String key, T Function(Map<String,dynamic>) fromJson) =>
      (json[key] as List? ?? const [])
        .whereType<Map>()
        .map((e)=>fromJson(Map<String,dynamic>.from(e))).toList();
    return EstatePilotDatabase(
      properties:parse('properties',PropertyModel.fromJson),
      clients:parse('clients',ClientModel.fromJson),
      leads:parse('leads',LeadModel.fromJson),
      followUps:parse('followUps',FollowUpModel.fromJson),
      activities:parse('activities',ActivityModel.fromJson),
      siteVisits:parse('siteVisits',SiteVisitModel.fromJson),
      deals:parse('deals',DealModel.fromJson),
      societies:parse('societies',SocietyModel.fromJson),
      marketRates:parse('marketRates',MarketRateModel.fromJson),
      verifications:parse('verifications',VerificationModel.fromJson),
      appSettings:parse('appSettings',AppSettingsModel.fromJson),
    );
  }
}

