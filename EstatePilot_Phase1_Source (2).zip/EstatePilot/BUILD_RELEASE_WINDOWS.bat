@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_RELEASE_WINDOWS.ps1"
if errorlevel 1 (
  echo Release build failed. Review the messages above.
  pause
  exit /b 1
)
pause
