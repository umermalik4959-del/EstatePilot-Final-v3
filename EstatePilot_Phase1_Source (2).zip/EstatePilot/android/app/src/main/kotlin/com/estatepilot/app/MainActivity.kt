package com.estatepilot.app

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channelName = "estatepilot/native"
    private val executor = Executors.newSingleThreadExecutor()
    private val mainThread = Handler(Looper.getMainLooper())
    private val db by lazy { EstateDatabase(this) }
    private var backupResult: MethodChannel.Result? = null
    private var pendingBackupText: String? = null
    private val exportRequest = 10991
    private val importRequest = 10992

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "getDataPath" -> result.success(filesDir.absolutePath)
                        "loadSnapshot" -> onBackground(result) { db.loadSnapshot() }
                        "saveSnapshot" -> {
                            val snapshot = call.argument<String>("snapshot") ?: error("Missing snapshot")
                            onBackground(result) { db.saveSnapshot(snapshot); true }
                        }
                        "exportBackup" -> {
                            if (backupResult != null) error("Another document operation is in progress")
                            pendingBackupText = call.argument<String>("json") ?: error("Missing backup")
                            backupResult = result
                            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "application/json"
                                putExtra(Intent.EXTRA_TITLE, "EstatePilot-backup.json")
                            }, exportRequest)
                        }
                        "importBackup" -> {
                            if (backupResult != null) error("Another document operation is in progress")
                            backupResult = result
                            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                addCategory(Intent.CATEGORY_OPENABLE)
                                type = "application/json"
                            }, importRequest)
                        }
                        "openDialer" -> {
                            val phone = call.argument<String>("phone").orEmpty()
                            require(phone.isNotBlank()) { "Phone number is missing" }
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}")))
                            result.success(true)
                        }
                        "openWhatsApp" -> {
                            val phone = normalizePhone(call.argument<String>("phone").orEmpty())
                            require(phone.isNotEmpty()) { "Phone number is missing" }
                            openWhatsApp(phone, call.argument<String>("message").orEmpty())
                            result.success(true)
                        }
                        "shareText" -> {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, call.argument<String>("text").orEmpty())
                            }
                            startActivity(Intent.createChooser(share, "Share from EstatePilot"))
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("ESTATEPILOT_NATIVE", e.message, null)
                }
            }
    }

    private fun onBackground(result: MethodChannel.Result, operation: () -> Any) {
        executor.execute {
            try {
                val value = operation()
                mainThread.post { result.success(value) }
            } catch (e: Exception) {
                mainThread.post { result.error("ESTATEPILOT_DATABASE", e.message, null) }
            }
        }
    }

    @Deprecated("Android intent result compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != exportRequest && requestCode != importRequest) return
        val callback = backupResult ?: return
        backupResult = null
        val backupText = pendingBackupText
        pendingBackupText = null
        if (resultCode != Activity.RESULT_OK || data?.data == null) {
            callback.success(null) // User cancelled; current data remains untouched.
            return
        }
        val uri = data.data!!
        onBackground(callback) {
            if (requestCode == exportRequest) {
                requireNotNull(backupText)
                contentResolver.openOutputStream(uri, "wt").use { stream ->
                    requireNotNull(stream) { "Unable to open backup destination" }
                    stream.write(backupText.toByteArray(Charsets.UTF_8))
                    stream.flush()
                }
                "saved"
            } else {
                contentResolver.openInputStream(uri).use { stream ->
                    requireNotNull(stream) { "Unable to read selected backup" }
                    stream.bufferedReader(Charsets.UTF_8).use { reader ->
                        val json = reader.readText()
                        require(json.length < 32_000_000) { "Backup is too large" }
                        json
                    }
                }
            }
        }
    }

    private fun normalizePhone(input: String): String {
        var digits = input.filter(Char::isDigit)
        if (digits.startsWith("0") && digits.length == 11) digits = "92" + digits.drop(1)
        return digits
    }

    private fun openWhatsApp(phone: String, message: String) {
        val encoded = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
        val uri = Uri.parse("https://wa.me/$phone?text=$encoded")
        for (pkg in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, uri).setPackage(pkg))
                return
            } catch (_: ActivityNotFoundException) { }
        }
        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
