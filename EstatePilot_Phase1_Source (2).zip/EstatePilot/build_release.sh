#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
command -v flutter >/dev/null || { echo 'Flutter SDK is not installed.' >&2; exit 1; }
WORKSPACE="$(mktemp -d)"
trap 'rm -rf "$WORKSPACE"' EXIT
flutter create --platforms=android --org com.estatepilot --project-name app "$WORKSPACE/app"
rm -rf "$WORKSPACE/app/lib" "$WORKSPACE/app/test" "$WORKSPACE/app/android/app/src/main"
cp -R "$ROOT/lib" "$WORKSPACE/app/lib"
cp -R "$ROOT/test" "$WORKSPACE/app/test"
cp -R "$ROOT/android/app/src/main" "$WORKSPACE/app/android/app/src/main"
cp "$ROOT/pubspec.yaml" "$ROOT/analysis_options.yaml" "$WORKSPACE/app/"
cd "$WORKSPACE/app"
flutter pub get
flutter analyze --no-fatal-warnings --no-fatal-infos
flutter test
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk "$ROOT/EstatePilot.apk"
echo "Created $ROOT/EstatePilot.apk (internal test signing; validate on a device)"
