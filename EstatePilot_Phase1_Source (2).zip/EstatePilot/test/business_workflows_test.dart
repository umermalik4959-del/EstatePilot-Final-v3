import 'package:flutter_test/flutter_test.dart';
import 'package:estatepilot/data/models.dart';
import 'package:estatepilot/data/local_store.dart';
import 'package:estatepilot/state/app_state.dart';

class FakeStore extends LocalStore {
  FakeStore(this.data);
  EstatePilotDatabase data;
  bool failOnSave = false;
  @override Future<EstatePilotDatabase> load() async => data;
  @override Future<void> save(EstatePilotDatabase incoming) async {
    if (failOnSave) throw StateError('Simulated disk failure');
    data = EstatePilotDatabase.fromJson(incoming.toJson());
  }
}

PropertyModel property(String id) => PropertyModel(
  id:id,propertyId:'EP-$id',referenceNo:'REF-$id',society:'B-17 Multi Gardens',block:'C',sector:'',street:'',
  plotNumber:'123',type:'Residential Plot',size:'8',unit:'Marla',purpose:'Sale',status:'Available',
  ownerDemand:9200000,askingPrice:9150000,expectedDealPrice:9000000,minimumPrice:8500000,
  salePrice:0,commission:0,tokenAmount:0,remainingAmount:0,paymentTerms:'',installmentAvailable:false,
  ownerName:'Property owner',ownerPhone:'03000000000',source:'Owner Direct',sourceContact:'',sourceDetail:'',
  roadWidth:'40',facing:'North',locationNotes:'',notes:'',corner:true,parkFacing:false,mainRoad:false,
  possession:true,electricity:true,gas:false,water:true,sewerage:true,negotiable:true,urgentSale:false,
  imagePaths:const [],videoPaths:const [],documentPaths:const [],history:const [],soldAt:null,
  createdAt:DateTime(2026,10,10),updatedAt:DateTime(2026,10,10));

ClientModel buyer(String id) => ClientModel(
  id:id,clientId:'C-$id',name:'Buyer',phone:'03001234567',
  whatsapp:'03001234567',email:'',city:'Islamabad',roles:['Buyer'],
  budgetMin:8000000,budgetMax:9500000,
  preferredSociety:'B-17 Multi Gardens',preferredPropertyType:'Residential Plot',
  preferredSize:'8',purpose:'Investment',timeline:'Immediate',
  preferences:['Corner','Possession'],source:'Referral',status:'Active',notes:'',
  createdAt:DateTime(2026,10,10),updatedAt:DateTime(2026,10,10));

void main() {
  test('empty business database contains no fake listings or clients', () {
    final db=EstatePilotDatabase();
    expect(db.properties,isEmpty);
    expect(db.clients,isEmpty);
    expect(db.deals,isEmpty);
  });

  test('advanced entities survive complete JSON round trip', () {
    final d=DealModel(id:'D-1',buyerId:'C-1',sellerId:'',propertyId:'P-1',
      finalPrice:10000000,token:1000000,commissionRate:1,
      commissionReceived:25000,status:'Token Received',notes:'',
      dealDate:DateTime(2026,10,10));
    final db=EstatePilotDatabase(deals:[d],siteVisits:[SiteVisitModel(
      id:'V-1',clientId:'C-1',propertyId:'P-1',scheduledAt:DateTime(2026,10,12),
      status:'Scheduled',outcome:'',notes:'',assignedTo:'',createdAt:DateTime(2026,10,10))],
      marketRates:[MarketRateModel(id:'R-1',society:'B-17',block:'C',size:'8 Marla',
      propertyType:'Residential Plot',askingRate:9000000,dealRate:8500000,
      recordedAt:DateTime(2026,10,10),source:'Manual',notes:'')]);
    final saved=EstatePilotDatabase.fromJson(db.toJson());
    expect(saved.deals.single.commissionTotal,100000);
    expect(saved.deals.single.commissionPending,75000);
    expect(saved.deals.single.remainingAmount,9000000);
    expect(saved.siteVisits.single.status,'Scheduled');
    expect(saved.marketRates.single.source,'Manual');
  });

  test('matching uses stored buyer requirements rather than fake scores', () async {
    final store=FakeStore(EstatePilotDatabase(
      properties:[property('1')],clients:[buyer('1')]));
    final state=AppState(store);
    await state.initialize();
    final results=state.matchesFor(state.clients.single);
    expect(results.length,1);
    expect(results.first.score,greaterThanOrEqualTo(80));
    expect(results.first.reasons.any((s)=>s.contains('Budget') ||
        s.contains('budget')),isTrue);
  });

  test('failed save does not commit visible unsaved property', () async {
    final store=FakeStore(EstatePilotDatabase());
    final state=AppState(store);
    await state.initialize();
    store.failOnSave=true;
    await expectLater(state.addProperty(property('P-1')),throwsStateError);
    expect(state.properties,isEmpty);
    expect(store.data.properties,isEmpty);
  });

  test('deal completion makes linked property sold and persists', () async {
    final store=FakeStore(EstatePilotDatabase(
      properties:[property('1')],clients:[buyer('1')]));
    final state=AppState(store);
    await state.initialize();
    await state.addDeal(DealModel(id:'D1',buyerId:'1',sellerId:'',propertyId:'1',
      finalPrice:9000000,token:1000000,commissionRate:1,
      commissionReceived:0,status:'Completed',notes:'',
      dealDate:DateTime(2026,10,10)));
    expect(state.properties.single.status,'Sold');
    expect(store.data.properties.single.status,'Sold');
    expect(state.completedDeals,1);
    expect(state.pendingCommission,90000);
  });
}
