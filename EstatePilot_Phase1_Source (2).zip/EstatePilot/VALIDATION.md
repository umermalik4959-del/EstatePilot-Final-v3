# EstatePilot v3 validation checklist

## Completed in source workspace
- [x] Project tree created
- [x] Relative imports checked
- [x] Dart/Kotlin delimiter balance checked
- [x] GitHub Actions YAML parsed
- [x] Native SQLite schema version synchronized with Dart backup schema (v3)
- [x] Luxury EstatePilot design tokens centralized
- [x] Property reference/source/history/media fields included
- [x] Active/Sold/Archived inventory behavior wired
- [x] Settings preferences persist in local database
- [x] App-private property media copy logic added
- [x] Model tests updated for v3 fields

## Must be executed in Flutter/Android environment
- [ ] `flutter pub get`
- [ ] `flutter analyze`
- [ ] `flutter test`
- [ ] `flutter build apk --release`
- [ ] APK install and launch
- [ ] add/edit/sell/archive/restore a property
- [ ] take/select a photo and confirm it remains after app restart
- [ ] add client/lead/follow-up/site visit/deal and confirm persistence
- [ ] backup/restore records
- [ ] upgrade from previous EstatePilot version without data loss
