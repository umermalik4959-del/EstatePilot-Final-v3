# EstatePilot Professional Source — v3

EstatePilot is an offline-first Android real-estate CRM for B-17 / Multi Gardens, Faisal Margalla City (FMC) and Faisal Hills. The source follows the approved luxury EstatePilot identity: near-black, charcoal, warm chocolate brown, restrained metallic gold and off-white. There is no blue primary theme.

## What is implemented in this source

- Premium dashboard with live counts for inventory, leads, clients, visits, follow-ups, deals and commission
- Property inventory with search, society/type/status filters, sorting and separate active/sold/archive behavior
- Detailed property records: Property ID, Reference No., society, block, sector, street, plot, type, size, status, source, source contact/detail and long-term record history
- Financial fields stored separately: owner demand, asking price, expected deal price, minimum price, final sale price, token, remaining amount, commission and payment terms
- Property photos, camera photos, gallery video, recorded video and document attachments; selected files are copied into EstatePilot app-private storage instead of keeping temporary picker paths
- Sold properties leave the default Active inventory view but remain in Sold/history; archived properties remain recoverable from Settings > Archive Management
- Clients / Client 360, buyer requirements and roles
- Lead pipeline, source, stage and Hot/Warm/Cold status
- Deterministic Smart Matching based on real stored criteria
- Site visits with outcomes and automatic follow-up creation for interested outcomes
- Follow-ups with Today / Overdue / Upcoming / Completed history
- Deals, token, closing stage, commission received/pending and automatic Reserved/Sold property status synchronization
- Societies, editable blocks and manually entered market-rate history
- Property verification checklist
- Search, Android dialer, WhatsApp intent and Android share intent
- Settings with profile, EstatePilot dark/light brand theme, default society, backup/restore, storage summary and archive management
- App-private transactional SQLite persistence through the native Android bridge
- Legacy JSON migration path and fail-safe behavior if local CRM storage cannot be opened

## Persistence design

`AppState` serializes every mutation. A UI change is committed only after the native SQLite transaction succeeds. The Android store writes each CRM entity under `(entity_type, record_id)` and replaces a full snapshot in one transaction, so a failed save does not present unsaved data as successful.

Normal app restarts, navigation and phone reboots do not intentionally clear records. Clearing Android app storage or uninstalling the application removes app-private storage, so export a backup first.

### Attachments

Property media is copied into the app-private `estatepilot_media` directory under Android `filesDir`. This prevents Android picker/cache cleanup from silently breaking stored attachments. The current JSON backup exports CRM records and attachment paths; it does **not yet package attachment bytes into the backup file**. For a commercial release, full media-bundle backup/restore should be added before relying on reinstall recovery for photos/videos/documents.

## Android build workflow

The source includes `.github/workflows/android-release.yml`.

The workflow:

1. installs Flutter stable and Java 17,
2. creates a fresh current Flutter Android scaffold,
3. copies EstatePilot Dart source, tests, pubspec and native Android `src/main`,
4. runs `flutter pub get`,
5. runs `flutter analyze`,
6. runs `flutter test`,
7. runs `flutter build apk --release`,
8. validates that the APK exists and publishes it as a GitHub Actions artifact.

This approach intentionally lets the current Flutter template own the Gradle wrapper/plugin versions instead of keeping an old Gradle wrapper in the source package.

## Honest validation status

This workspace does not contain Flutter/Dart/Android SDK, so the final commands below were **not** run here:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

The source bundle has been statically checked for balanced Dart/Kotlin delimiters, missing relative imports, duplicate property-model constructor call sites, YAML parse errors, and required project files. It is a source candidate, not a claim that an APK has already compiled.

## Final release checks still required

- actual Flutter analyzer/test/build pass
- installation and launch on a real Android phone
- CRUD persistence test after force-close/reboot
- upgrade/migration test from an older EstatePilot build
- backup/restore test
- attachment media backup bundle if reinstall recovery of media is required
- stable private Android release signing key for long-term updates / Play Store
- notification scheduling if background Android reminders are required

No fake properties, clients, leads or deals are inserted as business data. Only the three requested society reference records are seeded and remain editable.
