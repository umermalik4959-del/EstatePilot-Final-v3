$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
    throw 'Flutter SDK is not installed or not on PATH.'
}
$work = Join-Path $env:TEMP ('EstatePilotBuild_' + [guid]::NewGuid().ToString('N'))
$project = Join-Path $work 'app'
try {
    & flutter create --platforms=android --org com.estatepilot --project-name app $project
    if ($LASTEXITCODE -ne 0) { throw 'Flutter scaffold creation failed' }
    Remove-Item (Join-Path $project 'lib') -Recurse -Force
    Remove-Item (Join-Path $project 'test') -Recurse -Force
    Remove-Item (Join-Path $project 'android/app/src/main') -Recurse -Force
    Copy-Item (Join-Path $root 'lib') (Join-Path $project 'lib') -Recurse
    Copy-Item (Join-Path $root 'test') (Join-Path $project 'test') -Recurse
    Copy-Item (Join-Path $root 'android/app/src/main') (Join-Path $project 'android/app/src/main') -Recurse
    Copy-Item (Join-Path $root 'pubspec.yaml') $project
    Copy-Item (Join-Path $root 'analysis_options.yaml') $project
    Push-Location $project
    try {
        & flutter pub get; if ($LASTEXITCODE -ne 0) { throw 'pub get failed' }
        & flutter analyze --no-fatal-warnings --no-fatal-infos; if ($LASTEXITCODE -ne 0) { throw 'analyze failed' }
        & flutter test; if ($LASTEXITCODE -ne 0) { throw 'tests failed' }
        & flutter build apk --release; if ($LASTEXITCODE -ne 0) { throw 'APK build failed' }
    } finally { Pop-Location }
    Copy-Item (Join-Path $project 'build/app/outputs/flutter-apk/app-release.apk') (Join-Path $root 'EstatePilot.apk')
    Write-Host "Created EstatePilot.apk in $root (internal test signing)."
} finally {
    Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
}
